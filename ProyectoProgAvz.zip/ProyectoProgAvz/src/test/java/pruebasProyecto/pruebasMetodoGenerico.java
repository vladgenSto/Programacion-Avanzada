package pruebasProyecto;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Factura;
import modelo.Gestor;
import modelo.Llamada;

import org.junit.Test;

import tarifa.Tarifa;
import tarifa.TarifaBase;
import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaFecha;

public class pruebasMetodoGenerico {
	
	Gestor gestor = new Gestor();
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	Direccion direccion;
	
	public Llamada creadorLlamada(String NIF, String numeroDestinatario, int duracion, Date fecha) {
		Llamada nueva = new Llamada();
		nueva.setNIF(NIF);
		nueva.setNumero(numeroDestinatario);
		nueva.setDuracion(duracion);
		nueva.setFecha(fecha);
		return nueva;
	}
	
	public Factura creadorFactura(Tarifa tarifa, String nif, ArrayList<Date> periodo, Date fecha) throws ExcpecionPeriodo {
		Factura nueva = new Factura();
		nueva.setNIF(nif);
		nueva.setFecha(fecha);
		nueva.setTarifa(tarifa);
		nueva.setPeriodo(periodo);
		nueva.hashCode();
		return nueva;
	}
	
	@Test
	public void testClientes() throws ExcepcionNIF {
		System.out.println("Prueba getFechaClientes: ");
		direccion = factoriaCliente.nuevaDireccion("12004", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevoParticular("Pedro", "Ibañez", "12345678N", direccion);
		cliente1.setFecha(factoriaFecha.nuevaFecha(2014, 2, 3));
		Cliente cliente2 = factoriaCliente.nuevaEmpresa("Porcelanosa", "23456789B", direccion);
		cliente2.setFecha(factoriaFecha.nuevaFecha(2014, 2, 20));
		Cliente cliente3 = factoriaCliente.nuevoParticular("Paco", "Gimenez", "01234567C", direccion);
		cliente3.setFecha(factoriaFecha.nuevaFecha(2014, 3, 6));
		gestor.addCliente(cliente1);
		gestor.addCliente(cliente2);
		gestor.addCliente(cliente3);
		Date fechaInicio = factoriaFecha.nuevaFecha(2014, 2, 1);
		Date fechaFin = factoriaFecha.nuevaFecha(2014, 2, 28);
		System.out.println("Clientes: " + gestor.getFecha(gestor.listarClientes(), fechaInicio, fechaFin));
		System.out.println(cliente1.getFecha());
		assertTrue(gestor.getFecha(gestor.listarClientes(), fechaInicio, fechaFin).size()==2);
	
	}
	
	@Test
	public void testLlamadas() {
		System.out.println("Prueba getFechaLlamadas: ");
		direccion = factoriaCliente.nuevaDireccion("12004", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevoParticular("Pedro", "Ibañez", "12345678N", direccion);
		Llamada llamada1 = creadorLlamada(cliente1.getNIF(), "612345678", 10, factoriaFecha.nuevaFecha(2014, 4, 3));
		Llamada llamada2 = creadorLlamada(cliente1.getNIF(), "623456789", 5, factoriaFecha.nuevaFecha(2014, 4, 5));
		Llamada llamada3 = creadorLlamada(cliente1.getNIF(), "634567890", 15, factoriaFecha.nuevaFecha(2014, 4, 21));
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		gestor.addLlamada(llamada3);
		System.out.println("Llamdas: " + gestor.getFecha(gestor.listarLlamadas(cliente1.getNIF()), factoriaFecha.nuevaFecha(2014, 4, 1), factoriaFecha.nuevaFecha(2014, 4, 30)));
		assertTrue(gestor.getFecha(gestor.listarLlamadas(cliente1.getNIF()), factoriaFecha.nuevaFecha(2014, 4, 1), factoriaFecha.nuevaFecha(2014, 4, 30)).size() == 3);
	}

	@Test
	public void testFacturas() throws ExcpecionPeriodo, ExcepcionNIF {
		System.out.println("Prueba getFechaFacturas: ");

		ArrayList<Date> periodo = new ArrayList<Date>();
		
		Cliente cliente1 = factoriaCliente.nuevoParticular("Paco", "Gimenez", "01234567C", direccion);
		cliente1.setFecha(factoriaFecha.nuevaFecha(2014, 1, 1));
		gestor.addCliente(cliente1);
		
		Llamada llamada1 = creadorLlamada(cliente1.getNIF(), "612345678", 10, factoriaFecha.nuevaFecha(2014, 2, 2));
		Llamada llamada2 = creadorLlamada(cliente1.getNIF(), "623456789", 5, factoriaFecha.nuevaFecha(2014, 2, 5));
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		
		Date inicio = factoriaFecha.nuevaFecha(2014, 2, 1);
		Date fin = factoriaFecha.nuevaFecha(2014, 2, 29);
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println(gestor.facturasCliente(cliente1.getNIF()));
		assertTrue(gestor.getFecha(gestor.facturasCliente(cliente1.getNIF()), factoriaFecha.nuevaFecha(2014, 1, 30), factoriaFecha.nuevaFecha(2014, 3, 1)).size() == 1);

		llamada1 = creadorLlamada(cliente1.getNIF(), "612345678", 20, factoriaFecha.nuevaFecha(2014, 3, 2));
		llamada2 = creadorLlamada(cliente1.getNIF(), "623456789", 10, factoriaFecha.nuevaFecha(2014, 3, 20));
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		
		inicio = factoriaFecha.nuevaFecha(2014, 2, 28);
		fin = factoriaFecha.nuevaFecha(2014, 3, 30);
		periodo = new ArrayList<Date>();
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println(gestor.facturasCliente(cliente1.getNIF()));

		llamada1 = creadorLlamada(cliente1.getNIF(), "612345678", 8, factoriaFecha.nuevaFecha(2014, 4, 2));
		llamada2 = creadorLlamada(cliente1.getNIF(), "623456789", 14, factoriaFecha.nuevaFecha(2014, 4, 30));
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		
		inicio = factoriaFecha.nuevaFecha(2014, 4, 1);
		fin = factoriaFecha.nuevaFecha(2014, 4, 30);
		periodo = new ArrayList<Date>();
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println(gestor.facturasCliente(cliente1.getNIF()));

		System.out.println("Facturas: " + gestor.getFecha(gestor.facturasCliente(cliente1.getNIF()), factoriaFecha.nuevaFecha(2014, 2, 1), factoriaFecha.nuevaFecha(2014, 4, 30)));
		assertTrue(gestor.getFecha(gestor.facturasCliente(cliente1.getNIF()), factoriaFecha.nuevaFecha(2014, 2, 1), factoriaFecha.nuevaFecha(2014, 5, 30)).size() == 3);
	}

}
