package pruebasProyecto;

import static org.junit.Assert.*;
import static org.hamcrest.core.Is.*;

import java.util.Date;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Gestor;
import modelo.Llamada;
import modelo.Particular;

import org.junit.Test;

import excepciones.ExcepcionNIF;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaFecha;

public class pruebasGestorLlamadas {

	Gestor gestor = new Gestor();
	Date fechaLlamada = new Date();
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	Direccion direccion;
	
	public Llamada creadorLlamada(String NIF, String numeroDestinatario, int duracion, Date fecha) {
		Llamada nueva = new Llamada();
		nueva.setNIF(NIF);
		nueva.setNumero(numeroDestinatario);
		nueva.setDuracion(duracion);
		nueva.setFecha(fecha);
		return nueva;
	}
	
	@Test
	public void testAddLlamada() throws ExcepcionNIF {
		System.out.println("Prueba addLlamada: ");
		direccion = factoriaCliente.nuevaDireccion("12010", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevaEmpresa("Porcelanosa", "20124932N", direccion);
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 3, 20);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 10, fechaLlamada);
		assertTrue(gestor.addLlamada(nueva1));
		
		direccion = factoriaCliente.nuevaDireccion("12004", "Castellon", "Castellon");
		Cliente cliente2 = factoriaCliente.nuevoParticular("Maite", "Figueroa", "40392817B", direccion);
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 2, 10);
		Llamada nueva2 = creadorLlamada(cliente2.getNIF(), "601928472", 5, fechaLlamada);
		assertTrue(gestor.addLlamada(nueva2));
	}

	@Test
	public void testListarLlamadas() throws ExcepcionNIF {
		System.out.println("Prueba listarLlamadas: ");
		//Cliente 1:
		//Primera llamada
		direccion = factoriaCliente.nuevaDireccion("12004", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevoParticular("Maite", "Figueroa", "40392817B", direccion);
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 3, 20);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 10, fechaLlamada);
		gestor.addLlamada(nueva1);

		//Segunda llamada:
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 3, 21);
		Llamada nueva2 = creadorLlamada(cliente1.getNIF(), "678123890", 2, fechaLlamada);
		gestor.addLlamada(nueva2);
		
		System.out.println("Llamadas primer cliente");
		System.out.println(gestor.listarLlamadas(cliente1.getNIF()));
		assertThat(gestor.listarLlamadas(cliente1.getNIF()).isEmpty(), is(false));
		
		//Cliente 2:
		direccion = factoriaCliente.nuevaDireccion("12010", "Castellon", "Castellon");
		Cliente cliente2 = factoriaCliente.nuevaEmpresa("Porcelanosa", "20124932N", direccion);
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 2, 10);
		Llamada nueva3 = creadorLlamada(cliente2.getNIF(), "601928472", 5, fechaLlamada);
		gestor.addLlamada(nueva3);
		
		System.out.println("Llamadas segundo cliente");
		System.out.println(gestor.listarLlamadas(cliente2.getNIF()));
		assertThat(gestor.listarLlamadas(cliente2.getNIF()).isEmpty(), is(false));
		
		//Lista LLamadas de un cliente que no existe:
		System.out.println(gestor.listarLlamadas("12345678E"));
		assertTrue(gestor.listarLlamadas("12345678E") == null);
	}
	
	@Test
	public void testGetFecha() throws ExcepcionNIF {
		System.out.println("Prueba fecha llamada: ");
		direccion = factoriaCliente.nuevaDireccion("12004", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevoParticular("Maite", "Figueroa", "40392817B", direccion);
		fechaLlamada = factoriaFecha.nuevaFecha(2012, 3, 20);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 10, fechaLlamada);
		gestor.addLlamada(nueva1);
		
		System.out.println(nueva1.getFecha());
		assertTrue(nueva1.getFecha() != null);
		
		Llamada nueva2 = new Llamada();
		System.out.println(nueva2.getFecha());
		assertTrue(nueva2.getFecha() == null);
	}
}
