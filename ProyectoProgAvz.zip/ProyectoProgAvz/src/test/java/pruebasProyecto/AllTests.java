package pruebasProyecto;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ pruebasGestorClientes.class, pruebasGestorFacturacion.class,
		pruebasGestorLlamadas.class, pruebasMetodoGenerico.class })
public class AllTests {

}
