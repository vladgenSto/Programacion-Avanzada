package pruebasProyecto;

import es.uji.www.GeneradorDatosINE;

public class pruebaGenerador {

	public static void main(String[] args) {
		GeneradorDatosINE nuevoDato = new GeneradorDatosINE();
		for (int i=0; i<5; i++) {
			System.out.println(nuevoDato.getNombre() + ", " + nuevoDato.getApellido() + "\t" + nuevoDato.getNIF());
		}		
	}
}
