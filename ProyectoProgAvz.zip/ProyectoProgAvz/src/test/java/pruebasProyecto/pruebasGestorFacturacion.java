package pruebasProyecto;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Factura;
import modelo.Gestor;
import modelo.Llamada;

import org.junit.Test;

import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaFecha;
import factoryMethods.FactoriaTarifa;
import tarifa.Tarifa;

public class pruebasGestorFacturacion {

	Gestor gestor = new Gestor();
	Date fechaLlamada = new Date();
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	Direccion direccion;
	
	public Llamada creadorLlamada(String NIF, String numeroDestinatario, int duracion, Date fecha) {
		Llamada nueva = new Llamada();
		nueva.setNIF(NIF);
		nueva.setNumero(numeroDestinatario);
		nueva.setDuracion(duracion);
		nueva.setFecha(fecha);
		return nueva;
	}
	
	public Factura creadorFactura(Tarifa tarifa, String nif, ArrayList<Date> periodo, Date fecha) throws ExcpecionPeriodo {
		Factura nueva = new Factura();
		nueva.setNIF(nif);
		nueva.setFecha(fecha);
		nueva.hashCode();
		nueva.setTarifa(tarifa);
		nueva.setPeriodo(periodo);
		return nueva;
	}
	
	@Test
	public void testEmitirFactura() throws ExcepcionNIF, ExcpecionPeriodo {
		System.out.println("Prueba emitirFactura: ");
		//Cliente1:
		direccion = factoriaCliente.nuevaDireccion("12006", "Castellon", "Vinaroz");
		Cliente cliente1 = factoriaCliente.nuevaEmpresa("Pascual", "20124932N", direccion);
		gestor.addCliente(cliente1);
		
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 5);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 10);
		Llamada nueva2 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 20);
		Llamada nueva3 = creadorLlamada(cliente1.getNIF(), "612392817", 10, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);
		ArrayList<Date> periodo = new ArrayList<Date>();
		Date inicio = factoriaFecha.nuevaFecha(2016, 4, 1);
		Date fin = factoriaFecha.nuevaFecha(2016, 4, 30);
		periodo.add(inicio);
		periodo.add(fin);
		Factura factura = creadorFactura(cliente1.getTarifa(), cliente1.getNIF(), periodo, fin);
		System.out.println(gestor.emitirFactura(cliente1.getNIF(), periodo));
		assertTrue(gestor.emitirFactura(cliente1.getNIF(), periodo).equals(factura));
		
		//Cliente2:
		direccion = factoriaCliente.nuevaDireccion("12006", "Castellon", "Castellon");
		Cliente cliente2 = factoriaCliente.nuevoParticular("Albert", "Perez", "38271628N", direccion);
		gestor.addCliente(cliente2);
		gestor.cambiarTarifa(cliente2.getNIF(), factoriaTarifa.nuevaTarifaTardes(cliente2.getTarifa()));
		
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 0);
		nueva1 = creadorLlamada(cliente2.getNIF(), "658403283", 2, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 4, 9, 17, 45);
		nueva2 = creadorLlamada(cliente2.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 21);
		nueva3 = creadorLlamada(cliente2.getNIF(), "612392817", 3, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);
		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 3, 29);
		fin = factoriaFecha.nuevaFecha(2016, 4, 30);
		periodo.add(inicio);
		periodo.add(fin);
		factura = creadorFactura(cliente2.getTarifa(), cliente2.getNIF(), periodo, fin);
		System.out.println(gestor.emitirFactura(cliente2.getNIF(), periodo));
		assertTrue(gestor.emitirFactura(cliente2.getNIF(), periodo).equals(factura));
	}

	@Test
	public void testDatosFactura() throws ExcepcionNIF, ExcpecionPeriodo {
		System.out.println("Prueba datosFactura");
		direccion = factoriaCliente.nuevaDireccion("12007", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevaEmpresa("Pascual", "20124932N", direccion);
		gestor.addCliente(cliente1);
		
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 5);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 10);
		Llamada nueva2 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 20);
		Llamada nueva3 = creadorLlamada(cliente1.getNIF(), "612392817", 10, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);
		
		ArrayList<Date> periodo = new ArrayList<Date>();
		Date inicio = factoriaFecha.nuevaFecha(2016, 4, 0);
		Date fin = factoriaFecha.nuevaFecha(2016, 4, 30);
		periodo.add(inicio);
		periodo.add(fin);
		Date fecha = fin;
		Factura nueva = creadorFactura(cliente1.getTarifa(), cliente1.getNIF(), periodo, fecha);
		System.out.println(gestor.emitirFactura(cliente1.getNIF(), periodo));
		assertTrue(gestor.datosFactura(nueva.getCodfac()).getCodfac().equals(nueva.getCodfac()));
	}
	
	@Test
	public void testFacturasCliente() throws ExcepcionNIF, ExcpecionPeriodo {
		System.out.println("Prueba facturasCliente: ");
		direccion = factoriaCliente.nuevaDireccion("12007", "Castellon", "Castellon");
		Cliente cliente1 = factoriaCliente.nuevaEmpresa("Pascual", "20124932N", direccion);
		gestor.addCliente(cliente1);

		//Factura1:
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 5);
		Llamada nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 10);
		Llamada nueva2 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 4, 20);
		Llamada nueva3 = creadorLlamada(cliente1.getNIF(), "612392817", 10, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);
		
		ArrayList<Date> periodo = new ArrayList<Date>();
		Date inicio = factoriaFecha.nuevaFecha(2016, 4, 0);
		Date fin = factoriaFecha.nuevaFecha(2016, 4, 30);
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println("Lista facturas(fac1): " + gestor.facturasCliente(cliente1.getNIF()));
		assertTrue(gestor.facturasCliente(cliente1.getNIF()).size() == 1);
	
		//Factura2:
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 5, 4);
		nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 5, 10);
		nueva2 = creadorLlamada(cliente1.getNIF(), "658403283", 20, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 5, 20);
		nueva3 = creadorLlamada(cliente1.getNIF(), "612392817", 30, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);
		
		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 5, 0);
		fin = factoriaFecha.nuevaFecha(2016, 5, 30);
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println("Lista facturas(fac2): " + gestor.facturasCliente(cliente1.getNIF()));
		assertTrue(gestor.facturasCliente(cliente1.getNIF()).size() == 2);

		//Factura3:
		gestor.cambiarTarifa(cliente1.getNIF(), factoriaTarifa.nuevaTarifaDomingos(cliente1.getTarifa()));
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 6, 9);
		nueva1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 6, 14);
		nueva2 = creadorLlamada(cliente1.getNIF(), "658403283", 3, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 6, 23);
		nueva3 = creadorLlamada(cliente1.getNIF(), "612392817", 9, fechaLlamada);
		gestor.addLlamada(nueva1);
		gestor.addLlamada(nueva2);
		gestor.addLlamada(nueva3);

		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 6, 0);
		fin = factoriaFecha.nuevaFecha(2016, 6, 30);
		periodo.add(inicio);
		periodo.add(fin);
		gestor.emitirFactura(cliente1.getNIF(), periodo);
		System.out.println("Lista facturas(fac3): " + gestor.facturasCliente(cliente1.getNIF()));
		assertTrue(gestor.facturasCliente(cliente1.getNIF()).size() == 3);
	}
	
}
