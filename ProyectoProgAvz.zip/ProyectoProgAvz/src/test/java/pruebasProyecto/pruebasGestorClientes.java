package pruebasProyecto;

import static org.junit.Assert.*;
import static org.hamcrest.core.Is.*;

import java.io.FileNotFoundException;
import java.util.TreeMap;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Empresa;
import modelo.Gestor;
import modelo.Particular;

import org.junit.Test;

import tarifa.Domingos;
import tarifa.Tardes;
import tarifa.Tarifa;
import tarifa.TarifaBase;
import es.uji.www.GeneradorDatosINE;
import excepciones.ExcepcionNIF;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaTarifa;

public class pruebasGestorClientes {

	TreeMap<String, Cliente> lista = new TreeMap<String, Cliente>();
	Gestor gestor = new Gestor();
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	Cliente cliente;
	Direccion direccion;
	String nombre;
	String apellidos;
	String NIF;
	
	@Test
	public void testAddCliente() throws ExcepcionNIF {
		System.out.println("Prueba addCliente: ");
		for (int i=0; i<5; i++) {
			GeneradorDatosINE nuevo = new GeneradorDatosINE();
			direccion = factoriaCliente.nuevaDireccion("12006", "Castellon", "Vinaroz");
			cliente = factoriaCliente.nuevaEmpresa(nuevo.getNombre(), nuevo.getNIF(), direccion);
			assertTrue(gestor.addCliente(cliente).equals(cliente));
			System.out.println(gestor.datosCliente(cliente.getNIF()));
		}
	}
	
	@Test
	public void testRemoveCliente() throws ExcepcionNIF {
		System.out.println("Prueba removeCliente: ");
		direccion = factoriaCliente.nuevaDireccion("12006", "Castellon", "Vinaroz");
		cliente = factoriaCliente.nuevoParticular("Ana", "Gimenez", "20124932N", direccion);
		gestor.addCliente(cliente);
		System.out.println(gestor.datosCliente(cliente.getNIF()));
		assertTrue(gestor.removeCliente(cliente.getNIF()));
		
		direccion = factoriaCliente.nuevaDireccion("12300", "Castellon", "Villareal");
		Cliente cliente2 = factoriaCliente.nuevaEmpresa("Porcelanosa", "29182740B", direccion);
		gestor.addCliente(cliente);
		gestor.addCliente(cliente2);
		gestor.cambiarTarifa(cliente2.getNIF(), factoriaTarifa.nuevaTarifaDomingos(cliente2.getTarifa()));
		System.out.println(gestor.datosCliente(cliente2.getNIF()));
		assertTrue(gestor.removeCliente(cliente2.getNIF()));
		
		System.out.println(gestor.listarClientes());
		assertTrue(gestor.removeCliente(cliente.getNIF()));
	}
	
	@Test
	public void testCambiarTarifa() throws ExcepcionNIF {
		System.out.println("Prueba cambiarTarifa: ");
		Tarifa nuevaTarifa = factoriaTarifa.nuevaTarifaBasica();
		nuevaTarifa = factoriaTarifa.nuevaTarifaTardes(nuevaTarifa);
		direccion = factoriaCliente.nuevaDireccion("75800", "Madrid", "Marid");
		Cliente particular = factoriaCliente.nuevoParticular("Pedro", "Garcia","20408012B", direccion);
		gestor.addCliente(particular);
		gestor.cambiarTarifa(particular.getNIF(), nuevaTarifa);
		System.out.println(particular.getTarifa().getDescripcion());
		assertTrue(gestor.cambiarTarifa(particular.getNIF(), nuevaTarifa));
	}
	
	@Test
	public void testDatosCliente() throws ExcepcionNIF {
		System.out.println("Prueba datosCliente: ");
		//Particulares:
		direccion = factoriaCliente.nuevaDireccion("12006", "Castellon", "Vinaroz");
		cliente = factoriaCliente.nuevoParticular("Ana", "Gutierez", "20124932N", direccion);
		gestor.addCliente(cliente);
		gestor.cambiarTarifa(cliente.getNIF(), factoriaTarifa.nuevaTarifaTardes(cliente.getTarifa()));
		System.out.println(gestor.datosCliente(cliente.getNIF()));
		assertEquals(cliente, gestor.datosCliente(cliente.getNIF()));
		
		//Empresas:
		direccion = factoriaCliente.nuevaDireccion("12300", "Castellon", "Villareal");
		cliente = factoriaCliente.nuevaEmpresa("Porcelanosa", "29182740B", direccion);
		gestor.addCliente(cliente);
		gestor.cambiarTarifa(cliente.getNIF(), factoriaTarifa.nuevaTarifaDomingos(cliente.getTarifa()));
		System.out.println(gestor.datosCliente(cliente.getNIF()) + "\n");
		assertEquals(cliente, gestor.datosCliente(cliente.getNIF()));
	}
	
	@Test
	public void testListarClientes() throws ExcepcionNIF {
		System.out.println("Prueba listarClientes: ");
		for (int i=0; i<5; i++) {
			GeneradorDatosINE nuevo = new GeneradorDatosINE();
			nombre = nuevo.getNombre();
			apellidos = nuevo.getApellido();
			NIF = nuevo.getNIF();
			direccion = factoriaCliente.nuevaDireccion("12500", "Castellon", "Calig");
			cliente = factoriaCliente.nuevoParticular(nombre, apellidos, NIF, direccion);
			gestor.addCliente(cliente);
			assertTrue(gestor.listarClientes().contains(cliente));
		}
		System.out.println(gestor.listarClientes());
		assertThat(gestor.listarClientes().isEmpty(), is(false));
	}
	
}
