package pruebasPatronesDiseño;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Empresa;
import modelo.Factura;
import modelo.Gestor;
import modelo.Llamada;
import modelo.Particular;

import org.junit.Test;

import tarifa.Domingos;
import tarifa.Tardes;
import tarifa.Tarifa;
import tarifa.TarifaBase;
import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaFecha;
import factoryMethods.FactoriaTarifa;

public class Decorador {

	Gestor gestor = new Gestor();
	Date fechaLlamada = new Date();
	Tarifa tarifa = new TarifaBase();
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	Direccion direccion;
	
	public Llamada creadorLlamada(String NIF, String numeroDestinatario, int duracion, Date fecha) {
		Llamada nueva = new Llamada();
		nueva.setNIF(NIF);
		nueva.setNumero(numeroDestinatario);
		nueva.setDuracion(duracion);
		nueva.setFecha(fecha);
		return nueva;
	}
	
	public Factura creadorFactura(Tarifa tarifa, String nif, ArrayList<Date> periodo, Date fecha) throws ExcpecionPeriodo {
		Factura nueva = new Factura();
		nueva.setNIF(nif);
		nueva.setFecha(fecha);
		nueva.hashCode();
		nueva.setTarifa(tarifa);
		nueva.setPeriodo(periodo);
		return nueva;
	}
	
	@Test
	public void test() throws ExcepcionNIF, ExcpecionPeriodo {
		System.out.println("Prueba Decorador: ");
		System.out.println("Fatura con tarifa de Domingos: ");
		direccion = new Direccion("12006", "Castellon", "Villareal");
		Cliente cliente1 = factoriaCliente.nuevaEmpresa("Porcelanosa", "20124932N", direccion);
		gestor.addCliente(cliente1);
		gestor.cambiarTarifa(cliente1.getNIF(), factoriaTarifa.nuevaTarifaDomingos(cliente1.getTarifa()));
		
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 0, 2);
		Llamada llamada1 = creadorLlamada(cliente1.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFecha(2016, 0, 3);
		Llamada llamada2 = creadorLlamada(cliente1.getNIF(), "873430445", 5, fechaLlamada);
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		ArrayList<Date> periodo = new ArrayList<Date>();
		Date inicio = factoriaFecha.nuevaFecha(2016, 0, 0);
		Date fin = factoriaFecha.nuevaFecha(2016, 0, 30);
		periodo.add(inicio);
		periodo.add(fin);
		Factura factura1 = creadorFactura(cliente1.getTarifa(), cliente1.getNIF(), periodo, fin);
		System.out.println(periodo);
		System.out.println(gestor.emitirFactura(cliente1.getNIF(), periodo) + "\n");
		assertTrue(gestor.emitirFactura(cliente1.getNIF(), periodo).equals(factura1));
		
		System.out.println("Factura con tarifa de Tardes: ");
		direccion = new Direccion("12008", "Castellon", "Castellon");
		Cliente cliente2 = factoriaCliente.nuevoParticular("Confucio", "Confu", "40392817B", direccion);
		gestor.addCliente(cliente2);
		gestor.cambiarTarifa(cliente2.getNIF(), factoriaTarifa.nuevaTarifaTardes(cliente2.getTarifa()));

		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 1, 17, 0);
		llamada1 = creadorLlamada(cliente2.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 1, 12, 0);
		llamada2 = creadorLlamada(cliente2.getNIF(), "346456456", 5, fechaLlamada);
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 0, 0);
		fin = factoriaFecha.nuevaFecha(2016, 1, 0);
		periodo.add(inicio);
		periodo.add(fin);
		Factura factura2 = creadorFactura(cliente2.getTarifa(), cliente2.getNIF(), periodo, fin);
		System.out.println(periodo);
		System.out.println(gestor.emitirFactura(cliente2.getNIF(), periodo) + "\n");
		assertTrue(gestor.emitirFactura(cliente2.getNIF(), periodo).equals(factura2));
		
		System.out.println("Factura de Domingos que recubre una tarifa de Tardes: ");
		Cliente cliente3 = factoriaCliente.nuevoParticular("Miguel", "Pascual", "12345678N", direccion);
		gestor.addCliente(cliente3);
		gestor.cambiarTarifa(cliente3.getNIF(), factoriaTarifa.nuevaTarifaDomingos(factoriaTarifa.nuevaTarifaTardes(cliente3.getTarifa())));
		
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 2, 17, 0);
		llamada1 = creadorLlamada(cliente3.getNIF(), "658403283", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 5, 17, 1);
		llamada2 = creadorLlamada(cliente3.getNIF(), "658403283", 5, fechaLlamada);
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 0, 0);
		fin = factoriaFecha.nuevaFecha(2016, 1, 0);
		periodo.add(inicio);
		periodo.add(fin);
		Factura factura3 = creadorFactura(cliente3.getTarifa(), cliente3.getNIF(), periodo, fin);
		System.out.println(periodo);
		System.out.println(gestor.emitirFactura(cliente3.getNIF(), periodo));
		assertTrue(gestor.emitirFactura(cliente3.getNIF(), periodo).equals(factura3));
		
		System.out.println("Factura con tarifa de Tardes que recubre una tarifa de Domingos: ");
		direccion = new Direccion("12006", "Castellon", "Villareal");
		Cliente cliente4 = factoriaCliente.nuevaEmpresa("Facsa", "45678", direccion);
		gestor.addCliente(cliente4);
		gestor.cambiarTarifa(cliente4.getNIF(), factoriaTarifa.nuevaTarifaTardes(factoriaTarifa.nuevaTarifaDomingos(cliente4.getTarifa())));
		
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 2, 17, 0);
		System.out.println(fechaLlamada);
		llamada1 = creadorLlamada(cliente4.getNIF(), "6748393", 5, fechaLlamada);
		fechaLlamada = factoriaFecha.nuevaFechaYHora(2016, 0, 5, 17, 0);
		System.out.println(fechaLlamada);
		llamada2 = creadorLlamada(cliente4.getNIF(), "2628292", 5, fechaLlamada);
		gestor.addLlamada(llamada1);
		gestor.addLlamada(llamada2);
		periodo = new ArrayList<Date>();
		inicio = factoriaFecha.nuevaFecha(2016, 0, 0);
		fin = factoriaFecha.nuevaFecha(2016, 1, 0);
		periodo.add(inicio);
		periodo.add(fin);
		Factura factura4 = creadorFactura(cliente4.getTarifa(), cliente4.getNIF(), periodo, fin);
		System.out.println(periodo);
		System.out.println(gestor.emitirFactura(cliente4.getNIF(), periodo));
		assertTrue(gestor.emitirFactura(cliente4.getNIF(), periodo).equals(factura4));
	}

}
