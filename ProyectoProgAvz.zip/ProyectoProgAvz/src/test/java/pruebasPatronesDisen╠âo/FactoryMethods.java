package pruebasPatronesDiseño;

import static org.junit.Assert.*;

import java.util.Date;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Empresa;
import modelo.Gestor;
import modelo.Particular;

import org.junit.Test;

import tarifa.Domingos;
import tarifa.Tardes;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaFecha;
import factoryMethods.FactoriaTarifa;

public class FactoryMethods {

	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	Gestor gestor = new Gestor();
	Direccion direccion;
	
	@Test
	public void testClientes() {
		System.out.println("Prueba FactoryMethod de Clientes: ");
		direccion = factoriaCliente.nuevaDireccion("12003", "Castellon", "Castellon");
		System.out.println("La direccion es del tipo: " + direccion.getClass());
		assertTrue(direccion instanceof Direccion);
		Cliente particular = factoriaCliente.nuevoParticular("Paco", "Gimenez", "12345678N", direccion);
		System.out.println("Apellidos: " + particular.getApellidos());
		System.out.println("De que tipo es el cliente? " + particular.getClass());
		assertTrue(particular instanceof Particular);
		assertTrue(!particular.getApellidos().equals(null));
		
		direccion = factoriaCliente.nuevaDireccion("12010", "Castellon", "Villareal");
		System.out.println("La direccion es del tipo: " + direccion.getClass());
		assertTrue(direccion instanceof Direccion);
		Cliente empresa = factoriaCliente.nuevaEmpresa("Porcelanosa", "36364654", direccion);
		System.out.println("De que tipo es el cliente? " + empresa.getClass() + "\n");
		assertTrue(empresa instanceof Empresa);
		
	}
	
	@Test
	public void testTarifa() {
		System.out.println("Prueba FactoryMethod de Tarifa: ");
		direccion = factoriaCliente.nuevaDireccion("12003", "Castellon", "Castellon");
		Cliente particular = factoriaCliente.nuevoParticular("Paco", "Gimenez", "12345678N", direccion);
		gestor.addCliente(particular);
		gestor.cambiarTarifa(particular.getNIF(), factoriaTarifa.nuevaTarifaTardes(particular.getTarifa()));
		System.out.println("La tarifa del cliente " + particular.getNombre() + " es: " + particular.getTarifa());
		assertTrue(particular.getTarifa() instanceof Tardes);
		
		direccion = factoriaCliente.nuevaDireccion("12010", "Castellon", "Villareal");
		Cliente empresa = factoriaCliente.nuevaEmpresa("Porcelanosa", "36364654", direccion);
		gestor.addCliente(empresa);
		gestor.cambiarTarifa(empresa.getNIF(), factoriaTarifa.nuevaTarifaDomingos(empresa.getTarifa()));
		System.out.println("La tarifa del cliente " + empresa.getNombre() + " es: " + empresa.getTarifa() + "\n");
		assertTrue(empresa.getTarifa() instanceof Domingos);
	}
	
	@Test
	public void testFecha() {
		System.out.println("Prueba FactoryMethod de Fecha: ");
		Date fecha = factoriaFecha.nuevaFecha(2014, 3, 20);
		System.out.println("La fecha creada es: " + fecha);
		assertTrue(fecha instanceof Date);
		
		direccion = factoriaCliente.nuevaDireccion("12010", "Castellon", "Villareal");
		Cliente empresa = factoriaCliente.nuevaEmpresa("Porcelanosa", "36364654", direccion);
		empresa.setFecha(factoriaFecha.nuevaFecha(2012, 6, 23));
		System.out.println("La fecha de alta del cliente " + empresa.getNombre() + " es: " + empresa.getFecha());
		assertTrue(empresa.getFecha() instanceof Date);
		
		Date fechaYHora = factoriaFecha.nuevaFechaYHora(2014, 3, 20, 12, 10);
		System.out.println("La fechaYHora creada es: " + fechaYHora + "\n");
		assertTrue(fechaYHora instanceof Date);
	}

}
