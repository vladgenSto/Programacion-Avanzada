package modelo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaTarifa;
import tarifa.Tarifa;
import vista.InformaVista;

public class ImplementacionModelo implements CambiaModelo, InterrogaModelo {
	private InformaVista vista;
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	Gestor agenda = new Gestor();
	Cliente cliente;
	
	public ImplementacionModelo() {}
	
	public void setVista(InformaVista vista) {
		this.vista = vista;
	}

	@Override
	public void addCliente(Cliente cliente) {
		agenda.addCliente(cliente);
		System.out.println(agenda.datosCliente(cliente.getNIF()));
		vista.nuevoCliente();
	}

	@Override
	public boolean removeCliente(String NIF) {
		if (agenda.removeCliente(NIF)) {
			vista.clienteEliminado();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean cambiarTarifa(String NIF, String tarifa) {
		Tarifa tarifaCliente = agenda.datosCliente(NIF).getTarifa();
		if (tarifa.equals("Tarifa Tardes (0,05€/min)")) {
			tarifaCliente = factoriaTarifa.nuevaTarifaTardes(tarifaCliente);
			agenda.cambiarTarifa(NIF, tarifaCliente);
			vista.tarifaCambiada();
			return true;
		} else {
			if (tarifa.equals("Tarifa Domingos (gratis)")) {
				tarifaCliente = factoriaTarifa.nuevaTarifaDomingos(tarifaCliente);
				agenda.cambiarTarifa(NIF, tarifaCliente);
				vista.tarifaCambiada();
				return true;
			} else {
				if (tarifa.equals("Tarifa Basica (0,15€/min)")) {
					tarifaCliente = factoriaTarifa.nuevaTarifaBasica();
					agenda.cambiarTarifa(NIF, tarifaCliente);
					vista.tarifaCambiada();
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public void datosCliente(String NIF) {
		this.cliente = agenda.datosCliente(NIF);
		vista.infoCliente();
	}
	
	@Override
	public void buscarClientesPorFecha(ArrayList<Cliente> lista, Date fechaIn, Date fechaFin) {
		vista.dameClientes(agenda.getFecha(lista, fechaIn, fechaFin));
	}
	
	@Override
	public ArrayList<Cliente> clientes() {
		ArrayList<Cliente> respuesta = new ArrayList<Cliente>();
		Collection<Cliente> lista = agenda.listarClientes();
		for (Cliente cliente : lista) {
			respuesta.add(cliente);
		}
		return respuesta;
	}

	@Override
	public Cliente getCliente() {
		return cliente;
	}
	
	@Override
	public ArrayList<String> dameNifs() {
		ArrayList<String> respuesta = new ArrayList<String>();
		for (Cliente cliente : agenda.listarClientes()) {
			respuesta.add(cliente.getNIF());
		}
		return respuesta;
	}
	
	@Override
	public void addLlamada(Llamada llamada) {
		agenda.addLlamada(llamada);
		vista.nuevaLlamada();
	}
	
	@Override
	public void listaLlamadas(String NIF) {
		vista.listaLlamadas(agenda.listarLlamadas(NIF));
	}
	
	@Override
	public void llamadasCliente(String NIF) {
		vista.actualizarListaLlamadas(agenda.listarLlamadas(NIF));
	}

	@Override
	public void findLlamadasPorFecha(Collection<Llamada> lista, Date fechaInicio, Date fechaFin) {
		vista.dameLlamadas(agenda.getFecha(lista, fechaInicio, fechaFin));
	}
	
	@Override
	public void newFactura(String NIF, ArrayList<Date> periodo) throws ExcpecionPeriodo {
		Factura factura = agenda.emitirFactura(NIF, periodo);
		vista.facturaEmitida(factura.getCodfac());
	}
	
	@Override
	public void updateListaFac(String NIF) {
		vista.dameFacturasCliente(agenda.facturasCliente(NIF));
	}
	
	@Override
	public void datosFactura(String codfac) {
		vista.datosFac(agenda.datosFactura(codfac));
	}
	
	@Override
	public void listarFacturasCliente(String NIF) {
		vista.listadoFacturasCliente(agenda.facturasCliente(NIF));
	}
	
	@Override
	public void facturasCliente(String NIF) {
		vista.listaFacturasCliente(agenda.facturasCliente(NIF));
	}
	
	@Override
	public void findFacturasPorFecha(Collection<Factura> facturas, Date fechaIn, Date fechaFin) {
		vista.dameFacturas(agenda.getFecha(facturas, fechaIn, fechaFin));
	}
	
	@Override
	public void cargarDatos() {
		ObjectInputStream ois = null;
		try{
			try {
				FileInputStream fis = new FileInputStream("agenda.bin");
				ois = new ObjectInputStream(fis);
				agenda = (Gestor) ois.readObject();
				System.out.println("Datos cargados");
			}
			finally {
				if(ois != null) ois.close();
			}
		}
		catch(FileNotFoundException exc) {
			System.err.println("Fichero de datos no existe. Se crea una nueva agenda.");
		}
		catch(IOException exc) {
			exc.printStackTrace();
		}
		catch(ClassNotFoundException exc) {
			exc.printStackTrace();
		}
	}
	
	@Override
	public void guardarDatos() throws ExcepcionNIF, ParseException, ExcpecionPeriodo {
		ObjectOutputStream oos=null;
		try {
			try {
				FileOutputStream fos = new FileOutputStream("agenda.bin");
				oos = new ObjectOutputStream(fos);
				oos.writeObject(agenda);
				System.out.println("Datos guardados");
			}
			finally {
				oos.close();
			}
		}
		catch(FileNotFoundException exc) {
			System.out.println("El fichero no existe.");
			exc.printStackTrace();
		}
		catch(IOException exc) {
			exc.printStackTrace();
		}
	}
}
