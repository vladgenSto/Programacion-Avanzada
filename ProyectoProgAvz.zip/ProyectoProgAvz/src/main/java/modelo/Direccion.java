package modelo;

import java.io.Serializable;

public class Direccion implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3900189597839730474L;
	private String codpostal;
	private String provincia;
	private String poblacion;
	
	public Direccion(String codpostal, String provincia, String poblacion) {
		this.codpostal = codpostal;
		this.provincia = provincia;
		this.poblacion = poblacion;
	}
	
	public void setCodpostal(String codpostal) {
		this.codpostal = codpostal;
	}
	
	public String getCodpostal() {
		return codpostal;
	}
	
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	
	public String getProvincia() {
		return provincia;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}
	
	public String getPoblacion() {
		return poblacion;
	}
	
	public void setDireccion(String codpostal, String provincia, String pobliacion) {
		setCodpostal(codpostal);
		setProvincia(provincia);
		setPoblacion(pobliacion);
	}
		
	public String getDireccion() {
		return getCodpostal() + " " + getPoblacion() + " (" + getProvincia() + ")";	
	}
}
