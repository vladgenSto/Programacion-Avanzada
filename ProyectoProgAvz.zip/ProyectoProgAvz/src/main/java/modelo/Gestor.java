package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.TreeMap;

import tarifa.Tarifa;
import excepciones.ExcpecionPeriodo;

public class Gestor implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6597602859666921217L;
	private TreeMap<String, Cliente> listaClientes = new TreeMap<String, Cliente>();
	private TreeMap<String, Factura> listaFacturas = new TreeMap<String, Factura>();
	private TreeMap<String, ArrayList<Llamada>> listaLlamadas = new TreeMap<String, ArrayList<Llamada>>();
	private TreeMap<String, ArrayList<Factura>> listaFacturasCliente = new TreeMap<String, ArrayList<Factura>>();

	//Metodos Cliente:
	public Cliente addCliente(Cliente cliente) {
		listaClientes.put(cliente.getNIF(), cliente);
		return listaClientes.get(cliente.getNIF());
	}

	public boolean removeCliente(String NIF) {
		if (listaClientes.containsKey(NIF)) {
			listaClientes.remove(NIF);
			return true;
		} else {
			return false;
		}
	}

	public boolean cambiarTarifa(String NIF, Tarifa nuevaTarifa) {
		if (listaClientes.containsKey(NIF)) {
			listaClientes.get(NIF).setTarifa(nuevaTarifa);
			return true;
		} else {
			return false;
		}
	}

	public Cliente datosCliente(String NIF) {
		return listaClientes.get(NIF);
	}
	
	public Collection<Cliente> listarClientes() {
		return listaClientes.values();
	}
	
	//Metodos Factura:
	public Factura emitirFactura(String NIF, ArrayList<Date> periodo) throws ExcpecionPeriodo {
		if (listaClientes.containsKey(NIF)) {
			double importe = 0;
			Cliente cliente = listaClientes.get(NIF);
			Collection<Llamada> lista = this.listarLlamadas(NIF);
			for (Llamada llamada : lista) {
				if (llamada.getFecha().after(periodo.get(0))
						&& llamada.getFecha().before(periodo.get(1))) {
					importe += cliente.getTarifa().calcularPrecio(llamada);
				}
			}
			Factura nueva = new Factura();
			nueva.setFecha(periodo.get(1));
			nueva.setImporte(importe);
			nueva.setNIF(cliente.getNIF());
			nueva.setPeriodo(periodo);
			nueva.setTarifa(cliente.getTarifa());
			listaFacturas.put(nueva.getCodfac(), nueva);
			ArrayList<Factura> listaFac;
			if (!listaFacturasCliente.containsKey(cliente.getNIF())) {
				listaFac = new ArrayList<Factura>();
			} else {
				listaFac = listaFacturasCliente.get(cliente.getNIF());
			}
			listaFac.add(nueva);
			listaFacturasCliente.put(cliente.getNIF(), listaFac);
			return nueva;

		} else {
			return null;
		}
	}
		
	public Factura datosFactura(String codigoFactura) {
		return listaFacturas.get(codigoFactura);
	}
	
	public Collection<Factura> facturasCliente(String NIF) {
		return listaFacturasCliente.get(NIF);
	}
	
	//Metodos Llamada:
	public boolean addLlamada(Llamada nuevaLlamada) {
		if (!listaLlamadas.containsKey(nuevaLlamada.getNIF())) {
			ArrayList<Llamada> lista = new ArrayList<Llamada>();
			lista.add(nuevaLlamada);
			listaLlamadas.put(nuevaLlamada.getNIF(), lista);
			return true;
		} else {
			ArrayList<Llamada> lista = listaLlamadas.get(nuevaLlamada.getNIF());
			lista.add(nuevaLlamada);
			listaLlamadas.put(nuevaLlamada.getNIF(), lista);
			return true;
		}
	}
	
	public Collection<Llamada> listarLlamadas(String NIF) {
		return listaLlamadas.get(NIF);
		
	}
	
	//Metodo generico:
	public <T extends GetFecha> ArrayList<T> getFecha(Collection<T> lista, Date fechaInicio, Date fechaFinal) {
		ArrayList<T> respuesta = new ArrayList<T>();
		for(T elemento: lista) {
			if (elemento.getFecha().after(fechaInicio) && elemento.getFecha().before(fechaFinal)) {
				respuesta.add(elemento);
			}
		}
		return respuesta;
	}

}
