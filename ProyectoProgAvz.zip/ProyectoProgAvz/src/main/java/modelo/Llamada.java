package modelo;

import java.io.Serializable;
import java.util.Date;

public class Llamada implements GetFecha, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8137443622092075536L;
	private String NIF;
	private String codfac;
	private int duracion;
	private String numeroDestinatario;
	private Date fechaYHora;
		
	public Llamada() {}
	
	public String getNIF() {
		return NIF;
	}

	public void setNIF(String nIF) {
		NIF = nIF;
	}

	public String getCodfac() {
		return codfac;
	}

	public void setCodfac(String codfac) {
		this.codfac = codfac;
	}

	public String getNumero() {
		return numeroDestinatario;
	}

	public void setNumero(String numero) {
		this.numeroDestinatario = numero;
	}

	@Override
	public Date getFecha() {
		return fechaYHora;
	}

	public void setFecha(Date fechaYHora) {
		this.fechaYHora = fechaYHora;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	@Override
	public String toString() {
		String llamada = "NIF: " + getNIF() + "\nNumero al que llama: " +  getNumero() + " \nDuracion: " + getDuracion() + "\nFecha: " + getFecha();
		return llamada;
	}
}
