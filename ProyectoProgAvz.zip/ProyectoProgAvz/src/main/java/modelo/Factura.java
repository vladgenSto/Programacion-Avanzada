package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import tarifa.Tarifa;
import excepciones.ExcpecionPeriodo;

public class Factura implements GetFecha, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6568792032792689207L;
	private Tarifa tarifa;
	private String NIF;
	private ArrayList<Date> periodo;
	private double importe;
	private Date fechaEmision;
		
	public Factura() {}
		
	public String getCodfac() {
		return "" + hashCode();
	}

	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	public String getNIF() {
		return NIF;
	}

	public void setNIF(String nIF) {
		NIF = nIF;
	}

	@Override
	public Date getFecha() {
		return fechaEmision;
	}

	public void setFecha(Date fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public ArrayList<Date> getPeriodo() {
		return periodo;
	}

	public void setPeriodo(ArrayList<Date> periodo) throws ExcpecionPeriodo{
		if (periodo.get(0).after(periodo.get(1))) throw new ExcpecionPeriodo();
		else this.periodo = periodo;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((NIF == null) ? 0 : NIF.hashCode());
		result = prime * result + ((fechaEmision == null) ? 0 : fechaEmision.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Factura other = (Factura) obj;
		if (NIF == null) {
			if (other.NIF != null)
				return false;
		} else if (!NIF.equals(other.NIF))
			return false;
		if (fechaEmision == null) {
			if (other.fechaEmision != null)
				return false;
		} else if (!fechaEmision.equals(other.fechaEmision))
			return false;
		return true;
	}

	public String toString() {
		String infoFactura = "Codfac: " + getCodfac() + "\nNIF: " + getNIF() + "\nImporte: " + getImporte() + "\nTarifa: " + getTarifa().getDescripcion() + "\nFechaEmision: " + getFecha().getTime() + "\nPeriodo: " + getPeriodo().toString();
		return infoFactura;
	}

}
