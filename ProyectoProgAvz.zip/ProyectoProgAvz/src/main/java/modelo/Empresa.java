package modelo;



public class Empresa extends Cliente {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4424488814581117830L;

	public Empresa(String nombre, String NIF, Direccion direccion) {
		super(nombre, NIF, direccion);
	}

}
