package modelo;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;

public interface CambiaModelo {

	void addCliente(Cliente cliente);
	
	boolean removeCliente(String NIF);
	
	boolean cambiarTarifa(String NIF, String tarifa);
	
	void datosCliente(String NIF);

	void buscarClientesPorFecha(ArrayList<Cliente> lista, Date fechaIn, Date fechaFin);
	
	void addLlamada(Llamada llamada);
	
	void listaLlamadas(String NIF);
	
	void llamadasCliente(String NIF);
	
	void findLlamadasPorFecha(Collection<Llamada> lista, Date fechaInicio, Date fechaFin);
	
	void newFactura(String NIF, ArrayList<Date> periodo) throws ExcpecionPeriodo;
	
	void updateListaFac(String NIF);
	
	void datosFactura(String codfac);
	
	void listarFacturasCliente(String NIF);
	
	void facturasCliente(String NIF);
	
	void findFacturasPorFecha(Collection<Factura> lista, Date fechaIn, Date fechaFin);
		
	void guardarDatos() throws ExcepcionNIF, ParseException, ExcpecionPeriodo;
}
