package modelo;

import java.io.Serializable;
import java.util.Date;

import tarifa.Tarifa;
import tarifa.TarifaBase;
import excepciones.ExcepcionNIF;

public class Cliente implements GetFecha, Serializable {

	/**
	 * 
	 */
	protected static final long serialVersionUID = -3138217664195661903L;
	protected String nombre;
	protected String NIF;
	protected Tarifa tarifa;
	static protected String correo = "abcd@hotmail.com";
	protected Date fechaAlta;
	protected Direccion direccion;
	
	public Cliente(String nombre, String NIF, Direccion direccion) {
		this.nombre = nombre;
		this.NIF = NIF;
		this.tarifa = new TarifaBase();
		this.fechaAlta = new Date();
		this.direccion = direccion;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNIF() {
		return NIF;
	}

	public void setNIF(String nIF) throws ExcepcionNIF {
		if (nIF.length() > 9) throw new ExcepcionNIF();
		else NIF = nIF;
	}
	
	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

	public String getCorreo() {
		return correo;
	}

//	public void setCorreo(String correo) {
//		this.correo = correo;
//	}
	
	@Override
	public Date getFecha() {
		return fechaAlta;
	}

	public void setFecha(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	@Override
	public String toString() {
		String infoCliente = "NIF: " + getNIF() + "\nNombre: " + getNombre() + "\nDireccion: " + getDireccion() + "\n" + getTarifa().getDescripcion() + "\nFecha alta: " + getFecha();
		return infoCliente;
	}
	
	public void setApellidos(String string) {
		// TODO Auto-generated method stub	
	}

	public String getApellidos() {
		// TODO Auto-generated method stub
		return null;
	}
}
