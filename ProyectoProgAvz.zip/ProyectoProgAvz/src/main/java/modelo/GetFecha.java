package modelo;

import java.util.Date;

public interface GetFecha {
	
	Date getFecha();

}
