package modelo;

import java.util.ArrayList;

public interface InterrogaModelo {

	Cliente getCliente();

	ArrayList<Cliente> clientes();
		
	ArrayList<String> dameNifs();
	
	void cargarDatos();

}
