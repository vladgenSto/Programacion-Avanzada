package modelo;


public class Particular extends Cliente{

	/**
	 * 
	 */
	private static final long serialVersionUID = -371623574130580320L;
	private String apellidos;
	
	public Particular(String nombre, String apellidos, String NIF, Direccion direccion) {
		super(nombre, NIF, direccion);
		this.apellidos = apellidos;
	}
	
	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	@Override
	public String toString() {
		String infoCliente = "NIF: " + getNIF() + "\nNombre: " + getNombre() + "\nApellidos: " + getApellidos() + "\nDireccion: " + getDireccion() + "\n" + getTarifa().getDescripcion() + "\nFecha alta: " + getFecha();
		return infoCliente;
	}
	
}
