package controlador;

import java.text.ParseException;
import java.util.Collection;

import modelo.Factura;
import modelo.Llamada;
import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;

public interface Controlador {

	void addCliente();
	
	boolean removeCliente();
	
	boolean cambiarTarifa();
	
	void datosCliente();
	
	void buscarClientes();
	
	void añadirLlamada();
	
	void llamadasCliente();
	
	void buscarLlamadasDeCliente();
	
	void buscarLlamadasPorFecha(Collection<Llamada> lista);
	
	void nuevaFactura() throws ExcpecionPeriodo;
	
	void actualizarListaCodFac();
	
	void datosFac();
		
	void listaFac();
	
	void buscarFacturasDeCliente();
	
	void buscarFacturasPorFecha(Collection<Factura> lista);
	
	void guardarDatos() throws ExcepcionNIF, ParseException, ExcpecionPeriodo;
			
}
