package controlador;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaCliente;
import factoryMethods.FactoriaTarifa;
import modelo.CambiaModelo;
import modelo.Cliente;
import modelo.Direccion;
import modelo.Factura;
import modelo.Llamada;
import vista.InterrogaVista;

public class ImplementacionControlador implements Controlador{
	private InterrogaVista vista;
	private CambiaModelo modelo;
	FactoriaCliente factoriaCliente = new FactoriaCliente();
	FactoriaTarifa factoriaTarifa = new FactoriaTarifa();
	
	public ImplementacionControlador() {}
	
	public void setModelo(CambiaModelo modelo) {
		this.modelo = modelo;
	}
	
	public void setVista(InterrogaVista vista) {
		this.vista = vista;
	}
	
	@Override
	public void addCliente() {
		Cliente cliente;
		String tipoCliente = vista.getTipoCliente();
		String nombre = vista.getNombre();
		String apellido = vista.getApellido();
		String NIF = vista.getNIF();
		String poblacion = vista.getPoblacion();
		String provincia = vista.getProv();
		String codPostal = vista.getCodPostal();
		Date fechaAlta = vista.getFechaIn();
		String tipoTarifa = vista.getTipoTarifa();
		Direccion direccion = new Direccion(codPostal, provincia, poblacion);
		if (tipoCliente.equals("Empresa")) {
			cliente = factoriaCliente.nuevaEmpresa(nombre, NIF, direccion);
			cliente.setFecha(fechaAlta);
		} else {
			cliente = factoriaCliente.nuevoParticular(nombre, apellido, NIF, direccion);
			cliente.setFecha(fechaAlta);
		}
		modelo.addCliente(cliente);
		modelo.cambiarTarifa(NIF, tipoTarifa);
	}

	@Override
	public boolean removeCliente() {
		String NIF = vista.getNIF();
		if (modelo.removeCliente(NIF)) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public boolean cambiarTarifa() {
		String NIF = vista.getNIF();
		String tarifa = vista.getTipoTarifa();
		if (modelo.cambiarTarifa(NIF, tarifa)) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public void datosCliente() {
		String NIF = vista.getNIF();
		modelo.datosCliente(NIF);
	}

	@Override
	public void buscarClientes() {
		ArrayList<Cliente> lista = vista.listaDeClientes();
		Date fechaInicio = vista.getFechaIn();
		Date fechaFin = vista.getFechaFin();
		modelo.buscarClientesPorFecha(lista, fechaInicio, fechaFin);
	}
	
	@Override
	public void añadirLlamada() {
		String NIF = vista.getNIF();
		String numero = vista.getNumero();
		int duracion = vista.getDuracion();
		Date fechaLlamada = vista.getFechaIn();
		Llamada llamada = new Llamada();
		llamada.setNIF(NIF);
		llamada.setNumero(numero);
		llamada.setDuracion(duracion);
		llamada.setFecha(fechaLlamada);
		modelo.addLlamada(llamada);
	}
	
	@Override
	public void llamadasCliente() {
		String NIF = vista.getNIF();
		modelo.listaLlamadas(NIF);
	}
	
	@Override
	public void buscarLlamadasDeCliente() {
		String NIF = vista.getNIF();
		modelo.llamadasCliente(NIF);
	}
	
	@Override
	public void buscarLlamadasPorFecha(Collection<Llamada> lista) {
		Date fechaIn = vista.getFechaIn();
		Date fechaFin = vista.getFechaFin();
		modelo.findLlamadasPorFecha(lista, fechaIn, fechaFin);
	}
	
	@Override
	public void nuevaFactura() throws ExcpecionPeriodo {
		String NIF = vista.getNIF();
		ArrayList<Date> periodo = new ArrayList<Date>();
		periodo.add(vista.getFechaIn()); periodo.add(vista.getFechaFin());
		modelo.newFactura(NIF, periodo);
	}
	
	@Override
	public void actualizarListaCodFac() {
		String NIF = vista.getNIF();
		modelo.updateListaFac(NIF);
	}
	
	@Override
	public void datosFac() {
		String codFac = vista.getCodFac();
		modelo.datosFactura(codFac);
	}
	
	@Override
	public void listaFac() {
		String NIF = vista.getNIF();
		modelo.listarFacturasCliente(NIF);
	}
	
	@Override
	public void buscarFacturasDeCliente() {
		String NIF = vista.getNIF();
		modelo.facturasCliente(NIF);
	}
	
	@Override
	public void buscarFacturasPorFecha(Collection<Factura> lista) {
		Date fechaIn = vista.getFechaIn();
		Date fechaFin = vista.getFechaFin();
		modelo.findFacturasPorFecha(lista, fechaIn, fechaFin);
	}
	
	@Override
	public void guardarDatos() throws ExcepcionNIF, ParseException, ExcpecionPeriodo {
		modelo.guardarDatos();
	}
	
}
