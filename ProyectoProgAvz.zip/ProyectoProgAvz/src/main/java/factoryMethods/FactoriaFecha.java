package factoryMethods;

import java.io.Serializable;
import java.util.Date;

import modelo.Direccion;

public class FactoriaFecha implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7119742863608939053L;

	public FactoriaFecha() {
		super();
	}
	
	public Date nuevaFecha(int año, int mes, int dia) {
		return new Date(año, mes, dia);
	}
	
	public Date nuevaFechaYHora(int año, int mes, int dia, int hora, int minutos) {
		return new Date(año, mes, dia, hora, minutos);
	}
	
}
