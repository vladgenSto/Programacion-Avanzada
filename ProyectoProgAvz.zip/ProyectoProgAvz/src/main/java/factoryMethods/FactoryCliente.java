package factoryMethods;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Empresa;
import modelo.Particular;

public interface FactoryCliente {

	Cliente nuevoParticular(String nombre, String apellidos, String NIF, Direccion direccion);
	
	Cliente nuevaEmpresa(String nombre, String NIF, Direccion direccion);
	
	Direccion nuevaDireccion(String codpostal, String provincia, String poblacion);
	
}
