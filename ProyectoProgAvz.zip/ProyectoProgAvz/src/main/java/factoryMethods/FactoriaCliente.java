package factoryMethods;

import java.io.Serializable;

import modelo.Cliente;
import modelo.Direccion;
import modelo.Empresa;
import modelo.Particular;

public class FactoriaCliente implements FactoryCliente, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2953016670340540657L;
		
	public FactoriaCliente() {
		super();
	}
	
	@Override
	public Cliente nuevoParticular(String nombre, String apellidos, String NIF, Direccion direccion) {
		return new Particular(nombre, apellidos, NIF, direccion);
		
	}
	
	@Override
	public Cliente nuevaEmpresa(String nombre, String NIF, Direccion direccion) {
		return new Empresa(nombre, NIF, direccion);
	}
	
	@Override
	public Direccion nuevaDireccion(String codpostal, String provincia, String poblacion) {
		return new Direccion(codpostal, provincia, poblacion);
	}
	
}
