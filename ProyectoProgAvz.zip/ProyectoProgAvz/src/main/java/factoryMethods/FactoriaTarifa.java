package factoryMethods;

import java.io.Serializable;

import tarifa.Domingos;
import tarifa.Tardes;
import tarifa.Tarifa;
import tarifa.TarifaBase;

public class FactoriaTarifa implements FactoryTarifa, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 392946686652884419L;
	private Tarifa tarifa;
	
	public FactoriaTarifa() {
		super();
	}
	
	@Override
	public Tarifa nuevaTarifaBasica() {
		tarifa = new TarifaBase();
		return tarifa;
	}
	
	@Override
	public Tarifa nuevaTarifaTardes(Tarifa tarifa) {
		tarifa = new Tardes(tarifa, 0.05);
		return tarifa;

	}
	
	@Override
	public Tarifa nuevaTarifaDomingos(Tarifa tarifa) {
		tarifa = new Domingos(tarifa, 0);
		return tarifa;

	}
	
}
