package factoryMethods;

import tarifa.Domingos;
import tarifa.Tardes;
import tarifa.Tarifa;
import tarifa.TarifaBase;

public interface FactoryTarifa {

	Tarifa nuevaTarifaBasica();
	
	Tarifa nuevaTarifaTardes(Tarifa tarifa);
	
	Tarifa nuevaTarifaDomingos(Tarifa tarifa);
	
}
