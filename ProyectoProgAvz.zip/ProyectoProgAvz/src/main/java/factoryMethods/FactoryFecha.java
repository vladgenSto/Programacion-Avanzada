package factoryMethods;

import java.util.Date;

public interface FactoryFecha {

	Date nuevaFecha(int año, int mes, int dia);
	
	Date nuevaFechaYHora(int año, int mes, int dia, int hora, int minutos);
	
}
