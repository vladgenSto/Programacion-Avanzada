package excepciones;

public class ExcpecionPeriodo extends Exception{

	public ExcpecionPeriodo() {
		super("El periodo esta mal.");
	}
	
}
