package excepciones;

public class ExcepcionNIF extends Exception{

	public ExcepcionNIF() {
		super("El NIF es incorrecto.");
	}
	
}
