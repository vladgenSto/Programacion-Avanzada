package tarifa;

import modelo.Llamada;

public class TarifaBase extends Tarifa {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5893355808844622199L;
	private static double precio = 0.15;
	
	public TarifaBase() {
		super(precio);
	}
	
	@Override
	public String getDescripcion() {
		return "Tarifa Basica, la llamada sale a 0'15€/min";
	}

	@Override
	public double calcularPrecio(Llamada llamada) {
		return llamada.getDuracion() * precio;
	}
	
}
