package tarifa;

import modelo.Llamada;

public class Tardes extends Oferta {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3746683968606751456L;
	
	public Tardes(Tarifa tarifa, double precio) {
		super(tarifa, precio);
	}
	
	@Override
	public String getDescripcion() {
		return "Tarifa Tardes de 16:00 a 20:00, la llamada sale a 0'05€/min";
	}

	@Override
	public double calcularPrecio(Llamada llamada) {
		if (llamada.getFecha().getHours() >= 16 && llamada.getFecha().getHours() <= 20) {
			if (tarifa.calcularPrecio(llamada) > getPrecio() * llamada.getDuracion()) {
				return getPrecio() * llamada.getDuracion();
			}
		}
		return tarifa.calcularPrecio(llamada);
	}

}
