package tarifa;

import modelo.Llamada;

public abstract class Oferta extends Tarifa {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3217720495205966971L;
	protected Tarifa tarifa;
	
	public Oferta(Tarifa tarifa, double precio) {
		super(precio);
		this.tarifa = tarifa;
	}
	
	@Override
	public abstract double calcularPrecio(Llamada llamada);
	
}
