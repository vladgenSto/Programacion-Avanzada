package tarifa;

import modelo.Llamada;


public class Domingos extends Oferta{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8295778338870140076L;
	
	public Domingos(Tarifa tarifa, double precio) {
		super(tarifa, precio);
	}
	
	@Override
	public String getDescripcion() {
		return "Tarifa Domingos, la llamada sale a 0€/min";
	}

	@Override
	public double calcularPrecio(Llamada llamada) {
		if (llamada.getFecha().getDay() == 0) {
			if (tarifa.calcularPrecio(llamada) > getPrecio() * llamada.getDuracion()) {
				return getPrecio() * llamada.getDuracion();
			}
		}
		return tarifa.calcularPrecio(llamada);
	}
	
}
