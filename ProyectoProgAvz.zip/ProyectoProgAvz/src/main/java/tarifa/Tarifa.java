package tarifa;

import java.io.Serializable;

import modelo.Llamada;

public abstract class Tarifa implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3078033616523860990L;
	private double precio;
	
	public Tarifa(double precio) {
		this.precio = precio;
	}

	public double getPrecio() {
		return precio;
	}
	
	public abstract String getDescripcion();
	
	public abstract double calcularPrecio(Llamada llamada);
	
}
