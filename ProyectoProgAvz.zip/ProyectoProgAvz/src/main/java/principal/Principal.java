package principal;

import java.text.ParseException;

import modelo.ImplementacionModelo;
import controlador.ImplementacionControlador;
import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import vista.ImplementacionVista;

public class Principal {
	
	private Principal() {
		super();
	}
	
	public static void main(String[] args) throws ExcepcionNIF, ParseException, ExcpecionPeriodo {
		new Principal().ejecutar();
	}
	
	private void ejecutar() throws ExcepcionNIF, ParseException, ExcpecionPeriodo {
		ImplementacionControlador controlador = new ImplementacionControlador();
		ImplementacionVista vista = new ImplementacionVista();
		ImplementacionModelo modelo = new ImplementacionModelo();
		modelo.setVista(vista);
		controlador.setVista(vista);
		controlador.setModelo(modelo);
		vista.setMedelo(modelo);
		vista.setControlador(controlador);
		vista.ejecutar();
	}	
}
