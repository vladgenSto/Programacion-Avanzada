package vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.toedter.calendar.JCalendar;

import modelo.Cliente;
import modelo.Factura;
import modelo.InterrogaModelo;
import modelo.Llamada;
import controlador.Controlador;
import excepciones.ExcepcionNIF;
import excepciones.ExcpecionPeriodo;
import factoryMethods.FactoriaFecha;

public class ImplementacionVista implements InterrogaVista, InformaVista {
	private JFrame ventana = new JFrame("Menu Principal");
	FactoriaFecha factoriaFecha = new FactoriaFecha();
	private Controlador controlador;
	private InterrogaModelo modelo;
	JTabbedPane pestanyas = new JTabbedPane();
	JPanel panelClientes = new JPanel();
	JPanel panelLlamadas = new JPanel();
	JPanel panelFacturas = new JPanel();
	JSplitPane separadorClientes;
	JSplitPane separadorLlamadas;
	JSplitPane separadorFacturas;
	Dimension dimensiones;
	ActionListener escuchador;
	
	String tipoCliente;
	String codigoFac;
	JTextField rellenarNombre;
	JTextField rellenarApellido;
	JTextField rellenarNIF;
	JTextField rellenarPoblacion;
	JTextField rellenarProv;
	JTextField rellenarCodPostal;
	JTextField rellenarNumero;
	JTextField rellenarDuracion;
	JComboBox<String> lista;
	JComboBox<String> listaCodFac;
	JFrame ventanaCalendario;
	JCalendar calendario;
	Date fechaIn, fechaFin;
	int minutoIn, minutoFin;
	int horaIn, horaFin;
	JComboBox<String> minutos;
	JComboBox<String> horas;
	JComboBox<String> dias;
	JComboBox<String> meses;
	JComboBox<String> anyos;
	JCheckBox basica;
	JCheckBox tardes;
	JCheckBox domingos;
	JTextArea texto;
	
	String tipoTarifa;
	ArrayList<String> listaNif = new ArrayList<String>();
	ArrayList<String> listaFac = new ArrayList<String>();
	String[] Minutos = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"};
	String[] Horas = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"};
			
	public ImplementacionVista() {}
	
	public void setMedelo(InterrogaModelo modelo) {
		this.modelo = modelo;
	}
	
	public void setControlador(Controlador controlador) {
		this.controlador = controlador;
	}
	
	public void elementosVentanaCalInicio() {
		ventanaCalendario = new JFrame("Calendario");
		JPanel panelGeneral = new JPanel();
		panelGeneral.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new FlowLayout());
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new FlowLayout());
		
		JLabel minuto = new JLabel("Minuto: ");
		panelNorte.add(minuto);
		minutos = new JComboBox<String>(Minutos);
		panelNorte.add(minutos);
		JLabel hora = new JLabel("Hora: ");
		panelNorte.add(hora);
		horas = new JComboBox<String>(Horas);
		panelNorte.add(horas);
		
		calendario = new JCalendar();
		panelCentral.add(calendario);
		
		JButton aceptar = new JButton("Aceptar");dimensiones = new Dimension(100, 30); 
		aceptar.setPreferredSize(dimensiones);
		aceptar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				fechaIn = calendario.getDate();
				minutoIn = minutos.getSelectedIndex();
				horaIn = horas.getSelectedIndex();
				ventana.setVisible(true);
			}
		});
		panelSur.add(aceptar);
		panelGeneral.add(panelNorte, BorderLayout.NORTH);
		panelGeneral.add(panelCentral, BorderLayout.CENTER);
		panelGeneral.add(panelSur, BorderLayout.SOUTH);
		ventanaCalendario.add(panelGeneral);
		ventanaCalendario.pack();
		ventanaCalendario.setVisible(true);
	}
	
	public void elementosVentanaCalFin() {
		ventanaCalendario = new JFrame("Calendario");
		JPanel panelGeneral = new JPanel();
		panelGeneral.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new FlowLayout());
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new FlowLayout());
		
		JLabel minuto = new JLabel("Minuto: ");
		panelNorte.add(minuto);
		minutos = new JComboBox<String>(Minutos);
		panelNorte.add(minutos);
		JLabel hora = new JLabel("Hora: ");
		panelNorte.add(hora);
		horas = new JComboBox<String>(Horas);
		panelNorte.add(horas);
		
		calendario = new JCalendar();
		panelCentral.add(calendario);
		
		JButton aceptar = new JButton("Aceptar");dimensiones = new Dimension(100, 30); 
		aceptar.setPreferredSize(dimensiones);
		aceptar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				fechaFin = calendario.getDate();
				minutoFin = minutos.getSelectedIndex();
				horaFin = horas.getSelectedIndex();
				ventana.setVisible(true);
			}
		});
		panelSur.add(aceptar);
		panelGeneral.add(panelNorte, BorderLayout.NORTH);
		panelGeneral.add(panelCentral, BorderLayout.CENTER);
		panelGeneral.add(panelSur, BorderLayout.SOUTH);
		ventanaCalendario.add(panelGeneral);
		ventanaCalendario.pack();
		ventanaCalendario.setVisible(true);
	}
	
	public void ejecutar() throws ExcepcionNIF, ParseException, ExcpecionPeriodo {
		ventana.addWindowListener(new WindowListener() {
			
			@Override
			public void windowOpened(WindowEvent e) {
				modelo.cargarDatos();
				listaNif = modelo.dameNifs();
			}
			
			@Override
			public void windowClosing(WindowEvent e) {
				try {
					controlador.guardarDatos();
				} catch (ExcepcionNIF | ParseException | ExcpecionPeriodo e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub	
			}
		});
		ventana.pack();
		menuCliente(panelClientes);
		menuLlamadas(panelLlamadas);
		menuFacturas(panelFacturas);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setVisible(true);
	}
	
	@Override
	public Date getFechaIn() {
		return factoriaFecha.nuevaFechaYHora(fechaIn.getYear(), fechaIn.getMonth(), fechaIn.getDay(), horaIn, minutoIn);
	}
	
	@Override
	public Date getFechaFin() {
		return factoriaFecha.nuevaFechaYHora(fechaFin.getYear(), fechaFin.getMonth(), fechaFin.getDay(), horaFin, minutoFin);
	}
	
	@Override
	public String getTipoCliente() {
		return tipoCliente;
	}
	
	@Override
	public String getNombre() {
		return rellenarNombre.getText();
	}

	@Override
	public String getApellido() {
		return rellenarApellido.getText();
	}

	@Override
	public String getNIF() {
		return rellenarNIF.getText();
	}
	
	@Override
	public String getPoblacion() {
		return rellenarPoblacion.getText();
	}
	
	@Override
	public String getProv() {
		return rellenarProv.getText();
	}

	@Override
	public String getCodPostal() {
		return rellenarCodPostal.getText();
	}
	
	@Override
	public String getTipoTarifa() {
		return tipoTarifa;
	}
	
	@Override
	public String getNumero() {
		return rellenarNumero.getText();
	}
	
	@Override
	public int getDuracion() {
		return Integer.parseInt(rellenarDuracion.getText());
	}

	@Override
	public String getCodFac() {
		return codigoFac;
	}
	
	private void menuCliente(JPanel panel) {
		JPanel opcionesCliente = new JPanel();
		opcionesCliente.setLayout(new GridLayout(6, 1));
		separadorClientes = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, opcionesCliente, null);
		panelClientes.add(separadorClientes);
		
		JButton botonAdd = new JButton("Añadir cliente");
		opcionesCliente.add(botonAdd);
		anyadirCliente();
		botonAdd.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				anyadirCliente();
			}
		});
		
		JButton botonDel = new JButton("Borrar cliente");
		opcionesCliente.add(botonDel);
		botonDel.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				borrarCliente();
			}
		}); 
		
		JButton botonCambiarTarifa = new JButton("Cambiar tarifa");
		opcionesCliente.add(botonCambiarTarifa);
		botonCambiarTarifa.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				cambiarTarifa();				
			}
		});
		
		JButton botonData = new JButton("Datos del cliente");
		opcionesCliente.add(botonData);
		botonData.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				datosCliente();				
			}
		}); 
		
		JButton botonFind = new JButton("Buscar por fecha");
		opcionesCliente.add(botonFind);
		botonFind.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				buscarPorFecha();
			}
		}); 
		
		JButton botonList = new JButton("Listar clientes");
		opcionesCliente.add(botonList);
		botonList.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				listarClientes();
			}
		});
				
		pestanyas.addTab("Menu Cliente", panelClientes);
		ventana.getContentPane().add(pestanyas, BorderLayout.CENTER);
		dimensiones = new Dimension(850, 440);
		ventana.setSize(dimensiones);
	}
	
	private void menuLlamadas(JPanel panelLlamdas) {
		JPanel opcionesLlamadas = new JPanel();
		opcionesLlamadas.setLayout(new GridLayout(6, 1));
		separadorLlamadas = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, opcionesLlamadas, null);
		panelLlamadas.add(separadorLlamadas);
		
		JButton botonAdd = new JButton("Añadir llamada");
		opcionesLlamadas.add(botonAdd);
		anyadirLlamada();
		botonAdd.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				anyadirLlamada();
			}
		});
		
		JButton botonListar = new JButton("Listar llamadas");
		opcionesLlamadas.add(botonListar);
		botonListar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				listarLlamadas();
			}
		}); 
		
		JButton botonBuscar = new JButton("Buscar por fecha");
		opcionesLlamadas.add(botonBuscar);
		botonBuscar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				buscarLlamadas();				
			}
		});
		
		pestanyas.addTab("Menu Llamadas", panelLlamadas);
		ventana.getContentPane().add(pestanyas, BorderLayout.CENTER);
		dimensiones = new Dimension(850, 440);
		ventana.setSize(dimensiones);
	}
	
	private void menuFacturas(JPanel panel) {
		JPanel opcionesFacturas = new JPanel();
		opcionesFacturas.setLayout(new GridLayout(6, 1));
		separadorFacturas = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, opcionesFacturas, null);
		panelFacturas.add(separadorFacturas);

		JButton botonAdd = new JButton("Emitir factura");
		opcionesFacturas.add(botonAdd);
		anyadirFactura();
		botonAdd.addActionListener(escuchador = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				anyadirFactura();
			}
		});

		JButton datosFac = new JButton("Datos factura");
		opcionesFacturas.add(datosFac);
		datosFac.addActionListener(escuchador = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dataFac();
			}
		});

		JButton botonFacCli = new JButton("Facturas cliente");
		opcionesFacturas.add(botonFacCli);
		botonFacCli.addActionListener(escuchador = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				facClientes();
			}
		});
		
		JButton buscarPorFecha = new JButton("Buscar por fecha");
		opcionesFacturas.add(buscarPorFecha);
		buscarPorFecha.addActionListener(escuchador = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				buscarFacturas();
			}
		});

		pestanyas.addTab("Menu Facturas", panelFacturas);
		ventana.getContentPane().add(pestanyas, BorderLayout.CENTER);
		dimensiones = new Dimension(850, 440);
		ventana.setSize(dimensiones);
	}
	
	private void anyadirCliente() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new FlowLayout());
		JPanel panelFecha = new JPanel();
		panelFecha.setLayout(new FlowLayout());
		JPanel panelDate = new JPanel();
		panelDate.setLayout(new FlowLayout());
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new GridLayout(2, 3));
		separadorClientes.setRightComponent(camposCliente);

		rellenarApellido = new JTextField();
		JRadioButton empresa = new JRadioButton("Empresa");
		empresa.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (empresa.isSelected()) {
					tipoCliente = empresa.getText();
					rellenarApellido.setEnabled(false);
				}
			}
		});
		JRadioButton particular = new JRadioButton("Particular");
		particular.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (particular.isSelected()) {
					tipoCliente = particular.getText();
					rellenarApellido.setEnabled(true);
				}
			}
		});
		ButtonGroup tipo = new ButtonGroup();
		tipo.add(particular);
		tipo.add(empresa);
		panelNorte.add(empresa);
		panelNorte.add(particular);

		JLabel nombre = new JLabel("Nombre: ");
		panelCentral.add(nombre);
		rellenarNombre = new JTextField();
		dimensiones = new Dimension(560, 30);
		rellenarNombre.setPreferredSize(dimensiones);
		panelCentral.add(rellenarNombre);

		JLabel apellidos = new JLabel("Apellidos: ");
		panelCentral.add(apellidos);
		dimensiones = new Dimension(570, 30);
		rellenarApellido.setPreferredSize(dimensiones);
		panelCentral.add(rellenarApellido);
		
		JLabel NIF = new JLabel("NIF: ");
		panelCentral.add(NIF);
		rellenarNIF = new JTextField();
		dimensiones = new Dimension(540, 30);
		rellenarNIF.setPreferredSize(dimensiones);
		panelCentral.add(rellenarNIF);

		JLabel poblacion = new JLabel("Población: ");
		panelCentral.add(poblacion);
		rellenarPoblacion = new JTextField();
		dimensiones = new Dimension(570, 30);
		rellenarPoblacion.setPreferredSize(dimensiones);
		panelCentral.add(rellenarPoblacion);

		JLabel prov = new JLabel("Provincia: ");
		panelCentral.add(prov);
		rellenarProv = new JTextField();
		dimensiones = new Dimension(570, 30);
		rellenarProv.setPreferredSize(dimensiones);
		panelCentral.add(rellenarProv);

		JLabel codPostal = new JLabel("Codigo postal: ");
		panelCentral.add(codPostal);
		rellenarCodPostal = new JTextField();
		dimensiones = new Dimension(530, 30);
		rellenarCodPostal.setPreferredSize(dimensiones);
		panelCentral.add(rellenarCodPostal);
		
		JLabel fecha = new JLabel("Fecha de alta: ");
		panelFecha.add(fecha);
		
		JButton seleccionar = new JButton("Seleccionar");
		seleccionar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelDate.add(seleccionar);
		
		panelCentral.add(panelFecha);
		panelCentral.add(panelDate);

		basica = new JCheckBox("Tarifa Basica (0,15€/min)", true);
		basica.setEnabled(false);
		tipoTarifa = basica.getText();
		panelSur.add(basica);

		tardes = new JCheckBox("Tarifa Tardes (0,05€/min)", false);
		tardes.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tipoTarifa = tardes.getText();
			}
		});
		panelSur.add(tardes);

		domingos = new JCheckBox("Tarifa Domingos (gratis)", false);
		domingos.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tipoTarifa = domingos.getText();
			}
		});
		panelSur.add(domingos);
		
		JButton anyadir = new JButton("Añadir");
		anyadir.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				controlador.addCliente();
			}
		});
		panelSur.add(anyadir);
		
		JButton cancelar = new JButton("Cancelar");
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNombre.setText("");
				rellenarApellido.setText("");
				rellenarNIF.setText("");
				rellenarPoblacion.setText("");
				rellenarProv.setText("");
				rellenarCodPostal.setText("");
				tardes.setSelected(false);
				domingos.setSelected(false);
			}
		});
		panelSur.add(cancelar);
		
		camposCliente.add(panelNorte, BorderLayout.NORTH);
		camposCliente.add(panelCentral, BorderLayout.CENTER);
		camposCliente.add(panelSur, BorderLayout.SOUTH);
	}
	
	private void borrarCliente() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new FlowLayout());
		separadorClientes.setRightComponent(camposCliente);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		panelNorte.add(lista);
		camposCliente.add(panelNorte);
		
		JButton borrar = new JButton("Borrar");
		dimensiones = new Dimension(100, 30); 
		borrar.setPreferredSize(dimensiones);
		borrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.removeCliente();
			}
		});
		panelSur.add(borrar);
		
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30); 
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);				
			}
		});
		panelSur.add(cancelar);
		camposCliente.add(panelSur, BorderLayout.SOUTH);
	}
	
	private void cambiarTarifa() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new GridLayout(3, 1));
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new FlowLayout());
		separadorClientes.setRightComponent(camposCliente);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNorte.add(lista);
		
		basica = new JCheckBox("Tarifa Basica (0,15€/min)", false);
		basica.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tipoTarifa = basica.getText();
			}
		});
		panelCentral.add(basica);
		
		tardes = new JCheckBox("Tarifa Tardes (0,05€/min)", false);
		tardes.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tipoTarifa = tardes.getText();
			}
		});
		panelCentral.add(tardes);

		domingos = new JCheckBox("Tarifa Domingos (gratis)", false);
		domingos.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tipoTarifa = domingos.getText();				
			}
		});
		panelCentral.add(domingos);
		
		JButton cambiar = new JButton("Cambiar");
		dimensiones = new Dimension(100, 30); 
		cambiar.setPreferredSize(dimensiones);
		cambiar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.cambiarTarifa();		
			}
		});
		panelSur.add(cambiar);
		
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30); 
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);
				basica.setSelected(false);
				tardes.setSelected(false);
				domingos.setSelected(false);
			}
		});
		panelSur.add(cancelar);
		
		camposCliente.add(panelNorte, BorderLayout.NORTH);
		camposCliente.add(panelCentral, BorderLayout.CENTER);
		camposCliente.add(panelSur, BorderLayout.SOUTH);
	}
	
	public void datosCliente() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new GridLayout());
		separadorClientes.setRightComponent(camposCliente);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNorte.add(lista);
		
		texto = new JTextArea();
		dimensiones = new Dimension(100, 80);
		texto.setText("Muestra los datos del cliente seleccionado");
		
		JButton mostrar = new JButton("Mostrar");
		dimensiones = new Dimension(100, 30); 
		mostrar.setPreferredSize(dimensiones);
		mostrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.datosCliente();
			}
		}); 
		panelNorte.add(mostrar);
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(100, 80); 
		datos.setPreferredSize(dimensiones);
		panelCentral.add(datos);
		
		camposCliente.add(panelNorte, BorderLayout.NORTH);
		camposCliente.add(panelCentral, BorderLayout.CENTER);
	}
	
	private void buscarPorFecha() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new FlowLayout());
		JPanel fechaInicio = new JPanel();
		fechaInicio.setLayout(new FlowLayout());
		JPanel panelFechaIn = new JPanel();
		panelFechaIn.setLayout(new FlowLayout());
		JPanel fechaFin = new JPanel();
		fechaFin.setLayout(new FlowLayout());
		JPanel panelFechaFin = new JPanel();
		panelFechaFin.setLayout(new FlowLayout());
		JPanel botones = new JPanel();
		botones.setLayout(new FlowLayout());
		JPanel listaDatos = new JPanel();
		listaDatos.setLayout(new GridLayout());
				
		separadorClientes.setRightComponent(camposCliente);
		
		JLabel fechaIn = new JLabel("Fecha inicio: ");
		fechaInicio.add(fechaIn);
		
		JButton seleccionarIn = new JButton("Seleccionar");
		seleccionarIn.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelFechaIn.add(seleccionarIn);
		
		JLabel fechaF = new JLabel("Fecha fin: ");
		fechaFin.add(fechaF);
		
		JButton seleccionarFin = new JButton("Seleccionar");
		seleccionarFin.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalFin();			
			}
		});
		panelFechaFin.add(seleccionarFin);
		
		texto = new JTextArea();
		dimensiones = new Dimension(640, 250);
		texto.setText("Busca los clientes que han sido dados de alta en un periodo determinado");
		
		JButton buscar = new JButton("Buscar");
		dimensiones = new Dimension(100, 30);
		buscar.setPreferredSize(dimensiones);
		buscar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				controlador.buscarClientes();
			}
		});
		botones.add(buscar, BorderLayout.CENTER);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				texto.setText("");
			}
		});
		botones.add(cancelar, BorderLayout.EAST);
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(640, 250); 
		datos.setPreferredSize(dimensiones);
		listaDatos.add(datos);
		
		camposCliente.add(fechaInicio);
		camposCliente.add(panelFechaIn);
		camposCliente.add(fechaFin);
		camposCliente.add(panelFechaFin);
		camposCliente.add(botones);
		camposCliente.add(listaDatos);
	}

	public void listarClientes() {
		JPanel camposCliente = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposCliente.setPreferredSize(dimensiones);
		camposCliente.setLayout(new BorderLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new GridLayout());
		JPanel panelSur = new JPanel();
		panelSur.setLayout(new FlowLayout());
		separadorClientes.setRightComponent(camposCliente);
		
		texto = new JTextArea();
		dimensiones = new Dimension(400, 200);
		texto.setText("Muestra los datos de todos los clientes que se han registrado hasta el momento");
		
		JScrollPane listaClientes = new JScrollPane(texto);
		dimensiones = new Dimension(400, 200); 
		listaClientes.setPreferredSize(dimensiones);
		panelCentral.add(listaClientes);
		
		JButton mostrar = new JButton("Mostrar");
		dimensiones = new Dimension(100, 30);
		mostrar.setPreferredSize(dimensiones);
		mostrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String respuesta = "";
				for (int i=0; i<modelo.clientes().size(); i++) {
					respuesta += modelo.clientes().get(i) + "\n";
					respuesta += "--------------------------------------------------\n";
				}
				texto.setText(respuesta);
			}
		});
		panelSur.add(mostrar);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				texto.setText("");				
			}
		});
		panelSur.add(cancelar);
		
		camposCliente.add(panelCentral, BorderLayout.CENTER);
		camposCliente.add(panelSur, BorderLayout.SOUTH);
	}
	
	private void anyadirLlamada() {
		JPanel camposLlamadas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposLlamadas.setPreferredSize(dimensiones);
		camposLlamadas.setLayout(new GridLayout(8, 10));
		JPanel panelNif = new JPanel();
		panelNif.setLayout(new FlowLayout());
		JPanel panelNombre = new JPanel();
		panelNombre.setLayout(new FlowLayout());
		JPanel panelDuracion = new JPanel();
		panelDuracion.setLayout(new FlowLayout());
		JPanel panelFecha = new JPanel();
		panelFecha.setLayout(new FlowLayout());
		JPanel botones = new JPanel();
		botones.setLayout(new FlowLayout());
		separadorLlamadas.setRightComponent(camposLlamadas);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNif.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNif.add(lista);
		
		JLabel numero = new JLabel("Numero: ");
		panelNombre.add(numero);
		rellenarNumero = new JTextField();
		dimensiones = new Dimension(400, 30);
		rellenarNumero.setPreferredSize(dimensiones);
		panelNombre.add(rellenarNumero);
		
		JLabel duracion = new JLabel("Duración: ");
		panelDuracion.add(duracion);
		rellenarDuracion = new JTextField();
		dimensiones = new Dimension(400, 30);
		rellenarDuracion.setPreferredSize(dimensiones);
		panelDuracion.add(rellenarDuracion);
		
		JLabel fecha = new JLabel("Fecha de la llamada: ");
		panelFecha.add(fecha);
		
		JButton seleccionarIn = new JButton("Seleccionar");
		seleccionarIn.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelFecha.add(seleccionarIn);
		
		JButton anyadir = new JButton("Añadir");
		dimensiones = new Dimension(100, 30);
		anyadir.setPreferredSize(dimensiones);
		anyadir.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.añadirLlamada();	
			}
		});
		botones.add(anyadir);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);
				rellenarNumero.setText("");
				rellenarDuracion.setText("");
				
			}
		});
		botones.add(cancelar);
		
		camposLlamadas.add(panelNif);
		camposLlamadas.add(panelNombre);
		camposLlamadas.add(panelDuracion);
		camposLlamadas.add(panelFecha);
		camposLlamadas.add(botones);
	}
	
	private void listarLlamadas() {
		JPanel camposLlamadas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposLlamadas.setPreferredSize(dimensiones);
		camposLlamadas.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel listaLlamadas = new JPanel();
		listaLlamadas.setLayout(new GridLayout());
		separadorLlamadas.setRightComponent(camposLlamadas);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNorte.add(lista);
		
		texto = new JTextArea();
		dimensiones = new Dimension(400, 200);
		texto.setText("Muestra todas las llamadas que ha realizado el cliente seleccionado");
		
		JButton mostrar = new JButton("Mostrar");
		dimensiones = new Dimension(100, 30);
		mostrar.setPreferredSize(dimensiones);
		mostrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.llamadasCliente();
			}
		});
		panelNorte.add(mostrar);
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(400, 150); 
		datos.setPreferredSize(dimensiones);
		listaLlamadas.add(datos);
		
		camposLlamadas.add(panelNorte, BorderLayout.NORTH);
		camposLlamadas.add(listaLlamadas, BorderLayout.CENTER);
	}
	
	private void buscarLlamadas() {
		JPanel camposLlamadas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposLlamadas.setPreferredSize(dimensiones);
		camposLlamadas.setLayout(new BorderLayout());
		JPanel panelNif = new JPanel();
		panelNif.setLayout(new FlowLayout());
		JPanel panelFecha = new JPanel();
		panelFecha.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new BorderLayout());
		JPanel botones = new JPanel();
		botones.setLayout(new FlowLayout());
		JPanel listaLlamadas = new JPanel();
		listaLlamadas.setLayout(new FlowLayout());
		separadorLlamadas.setRightComponent(camposLlamadas);		
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNif.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNif.add(lista);
		
		JLabel fechaIn = new JLabel("Fecha inicio: ");
		panelFecha.add(fechaIn);
		
		JButton seleccionarIn = new JButton("Seleccionar");
		seleccionarIn.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelFecha.add(seleccionarIn);
		
		JLabel fechaF = new JLabel("Fecha fin: ");
		panelFecha.add(fechaF);
		
		JButton seleccionarFin = new JButton("Seleccionar");
		seleccionarFin.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalFin();			
			}
		});
		panelFecha.add(seleccionarFin);
		panelCentral.add(panelFecha, BorderLayout.NORTH);
		
		texto = new JTextArea();
		dimensiones = new Dimension(640, 250);
		texto.setText("Busca las llamadas del cliente seleccionado que se han realizado en un determinado periodo");
		
		JButton buscar = new JButton("Buscar");
		dimensiones = new Dimension(100, 30);
		buscar.setPreferredSize(dimensiones);
		buscar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.buscarLlamadasDeCliente();			
			}
		});
		botones.add(buscar);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);
			}
		});
		botones.add(cancelar);
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(640, 220); 
		datos.setPreferredSize(dimensiones);
		listaLlamadas.add(datos);
		panelCentral.add(listaLlamadas, BorderLayout.CENTER);
		
		camposLlamadas.add(panelNif, BorderLayout.NORTH);
		camposLlamadas.add(panelCentral, BorderLayout.CENTER);
		camposLlamadas.add(botones, BorderLayout.SOUTH);
	}
	
	private void anyadirFactura() {
		JPanel camposFacturas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposFacturas.setPreferredSize(dimensiones);
		camposFacturas.setLayout(new BorderLayout());
		JPanel panelNif = new JPanel();
		panelNif.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new FlowLayout());
		JPanel panelFechaIn = new JPanel();
		panelFechaIn.setLayout(new FlowLayout());
		JPanel panelFechaFin = new JPanel();
		panelFechaFin.setLayout(new FlowLayout());
		JPanel botones = new JPanel();
		botones.setLayout(new FlowLayout());
		separadorFacturas.setRightComponent(camposFacturas);		
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNif.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNif.add(lista);
		
		JLabel fechaIn = new JLabel("Fecha inicio: ");
		panelFechaIn.add(fechaIn);
		
		JButton seleccionarIn = new JButton("Seleccionar");
		seleccionarIn.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelFechaIn.add(seleccionarIn);
		panelCentral.add(panelFechaIn);
		
		JLabel fechaF = new JLabel("Fecha fin: ");
		panelFechaFin.add(fechaF);
		
		JButton seleccionarFin = new JButton("Seleccionar");
		seleccionarFin.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalFin();			
			}
		});
		panelFechaFin.add(seleccionarFin);
		panelCentral.add(panelFechaFin);
		
		JButton emitir = new JButton("Emitir");
		dimensiones = new Dimension(100, 30);
		emitir.setPreferredSize(dimensiones);
		emitir.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				try {
					controlador.nuevaFactura();
				} catch (ExcpecionPeriodo e1) {
					System.out.println("El periodo no es correcto");
					e1.printStackTrace();
				}
			}
		});
		botones.add(emitir);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);
			}
		});
		botones.add(cancelar);
		
		camposFacturas.add(panelNif, BorderLayout.NORTH);
		camposFacturas.add(panelCentral, BorderLayout.CENTER);
		camposFacturas.add(botones, BorderLayout.SOUTH);
	}
	
	private void dataFac() {
		JPanel camposFacturas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposFacturas.setPreferredSize(dimensiones);
		camposFacturas.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new GridLayout());
		separadorFacturas.setRightComponent(camposFacturas);
				
		JLabel NIF = new JLabel("Selecciona NIF:");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		lista.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.actualizarListaCodFac();			
			}
		});
		panelNorte.add(lista);
		JLabel codFac = new JLabel("Selecciona factura:");
		panelNorte.add(codFac);
		listaCodFac = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		listaCodFac.setPreferredSize(dimensiones);
		listaCodFac.addItem("Codigo Factura");
		listaCodFac.setSelectedIndex(0);
		for (int i=0; i<listaFac.size(); i++) {
			listaCodFac.addItem(listaFac.get(i));
		}
		
		panelNorte.add(listaCodFac);
		JButton mostrar = new JButton("Mostrar");
		dimensiones = new Dimension(100, 30);
		mostrar.setPreferredSize(dimensiones);
		mostrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				codigoFac = listaCodFac.getSelectedItem().toString();
				controlador.datosFac();
			}
		});
		panelNorte.add(mostrar);
		
		texto = new JTextArea();
		dimensiones = new Dimension(640, 500);
		texto.setText("Muestra los datos de la factura seleccionada");
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(640, 500); 
		datos.setPreferredSize(dimensiones);
		panelCentral.add(datos);
		
		camposFacturas.add(panelNorte, BorderLayout.NORTH);
		camposFacturas.add(panelCentral, BorderLayout.CENTER);
	}
	
	private void facClientes() {
		JPanel camposFacturas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposFacturas.setPreferredSize(dimensiones);
		camposFacturas.setLayout(new BorderLayout());
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout());
		JPanel listaFacturas = new JPanel();
		listaFacturas.setLayout(new GridLayout());
		separadorFacturas.setRightComponent(camposFacturas);
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNorte.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNorte.add(lista);
		
		JButton mostrar = new JButton("Mostrar");
		dimensiones = new Dimension(100, 30);
		mostrar.setPreferredSize(dimensiones);
		mostrar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.listaFac();
			}
		});
		panelNorte.add(mostrar);
		
		texto = new JTextArea();
		dimensiones = new Dimension(640, 500);
		texto.setText("Muestra todas las facturas que ha realizado hasta el momento el cliente seleccionado");
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(640, 500); 
		datos.setPreferredSize(dimensiones);
		listaFacturas.add(datos);
		
		camposFacturas.add(panelNorte, BorderLayout.NORTH);
		camposFacturas.add(listaFacturas, BorderLayout.CENTER);
	}
	
	private void buscarFacturas() {
		JPanel camposFacturas = new JPanel();
		dimensiones = new Dimension(650, 350);
		camposFacturas.setPreferredSize(dimensiones);
		camposFacturas.setLayout(new BorderLayout());
		JPanel panelNif = new JPanel();
		panelNif.setLayout(new FlowLayout());
		JPanel panelCentral = new JPanel();
		panelCentral.setLayout(new BorderLayout());
		JPanel panelFecha = new JPanel();
		panelFecha.setLayout(new FlowLayout());
		JPanel botones = new JPanel();
		botones.setLayout(new FlowLayout());
		JPanel listaFacturas = new JPanel();
		listaFacturas.setLayout(new FlowLayout());
		separadorFacturas.setRightComponent(camposFacturas);		
		
		JLabel NIF = new JLabel("Seleccione un cliente: ");
		panelNif.add(NIF);
		lista = new JComboBox<String>();
		dimensiones = new Dimension(150, 30); 
		lista.setPreferredSize(dimensiones);
		lista.addItem("----NIF----");
		lista.setSelectedIndex(0);
		for (int i=0; i<listaNif.size(); i++) {
			lista.addItem(listaNif.get(i));
		}
		panelNif.add(lista);
		
		JLabel fechaIn = new JLabel("Fecha inicio: ");
		panelFecha.add(fechaIn);
		
		JButton seleccionarIn = new JButton("Seleccionar");
		seleccionarIn.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalInicio();			
			}
		});
		panelFecha.add(seleccionarIn);
		
		JLabel fechaF = new JLabel("Fecha fin: ");
		panelFecha.add(fechaF);
		
		JButton seleccionarFin = new JButton("Seleccionar");
		seleccionarFin.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				elementosVentanaCalFin();			
			}
		});
		panelFecha.add(seleccionarFin);
		panelCentral.add(panelFecha, BorderLayout.NORTH);
		
		JButton buscar = new JButton("Buscar");
		dimensiones = new Dimension(100, 30);
		buscar.setPreferredSize(dimensiones);
		buscar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rellenarNIF.setText(lista.getSelectedItem().toString());
				controlador.buscarFacturasDeCliente();
			}
		});
		botones.add(buscar, BorderLayout.CENTER);
		JButton cancelar = new JButton("Cancelar");
		dimensiones = new Dimension(100, 30);
		cancelar.setPreferredSize(dimensiones);
		cancelar.addActionListener(escuchador = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lista.setSelectedIndex(0);				
			}
		});
		botones.add(cancelar, BorderLayout.EAST);
		
		texto = new JTextArea();
		dimensiones = new Dimension(640, 220);
		texto.setText("Busca las facturas del cliente seleccionado que se han realizado en un determinado periodo");
		
		JScrollPane datos = new JScrollPane(texto);
		dimensiones = new Dimension(640, 220); 
		datos.setPreferredSize(dimensiones);
		listaFacturas.add(datos);
		panelCentral.add(listaFacturas, BorderLayout.CENTER);
		
		camposFacturas.add(panelNif, BorderLayout.NORTH);
		camposFacturas.add(panelCentral, BorderLayout.CENTER);
		camposFacturas.add(botones, BorderLayout.SOUTH);
	}

	@Override
	public void nuevoCliente() {
		listaNif.add(rellenarNIF.getText());
		listaNif.sort(null);
		rellenarNombre.setText("");
		rellenarApellido.setText("");
		rellenarNIF.setText("");
		rellenarPoblacion.setText("");
		rellenarProv.setText("");
		rellenarCodPostal.setText("");
		minutos.setSelectedIndex(0);
		horas.setSelectedIndex(0);
		dias.setSelectedIndex(0);
		meses.setSelectedIndex(0);
		anyos.setSelectedIndex(0);
		tardes.setSelected(false);
		domingos.setSelected(false);
	}
	
	@Override
	public void clienteEliminado() {
		listaNif.remove(getNIF());
		listaNif.sort(null);
		lista.revalidate();
		lista.setSelectedIndex(0);
	}
	
	@Override
	public void tarifaCambiada() {
		lista.setSelectedIndex(0);
		basica.setSelected(false);
		tardes.setSelected(false);
		domingos.setSelected(false);
	}
	
	@Override
	public void infoCliente() {
		texto.setText(modelo.getCliente().toString());
	}
	
	@Override
	public ArrayList<Cliente> listaDeClientes() {
		return modelo.clientes();
	}
	
	@Override
	public void dameClientes(ArrayList<Cliente> clientes) {
		String respuesta = "";
		for (Cliente cliente : clientes) {
			respuesta += cliente + "\n";
			respuesta += "----------------------------------------\n";
		}
		texto.setText(respuesta);
	}
	
	@Override
	public void nuevaLlamada() {
		System.out.println("Llamada añadida");
	}
	
	@Override
	public void listaLlamadas(Collection<Llamada> lista) {
		String respuesta = "";
		for (Llamada llamada : lista) {
			respuesta += llamada + "\n";
			respuesta += "----------------------------------------\n";

		}
		texto.setText(respuesta);
	}
	
	@Override
	public void actualizarListaLlamadas(Collection<Llamada> lista) {
		controlador.buscarLlamadasPorFecha(lista);
	}
	
	@Override
	public void dameLlamadas(ArrayList<Llamada> llamadas) {
		String respuesta = "";
		for (Llamada llamada : llamadas) {
			respuesta += llamada + "\n";
		}
		texto.setText(respuesta);
	}
	
	@Override
	public void facturaEmitida(String codFac) {
		lista.setSelectedIndex(0);
	}
	
	@Override
	public void dameFacturasCliente(Collection<Factura> facturas) {
		listaFac = new ArrayList<String>();
		for (Factura factura : facturas) {
			listaFac.add(factura.getCodfac());
		}
		listaCodFac.revalidate();
		listaFac.sort(null);
	}
	
	@Override
	public void datosFac(Factura factura) {
		texto.setText(factura.toString());
	}
	
	@Override
	public void listadoFacturasCliente(Collection<Factura> facturas) {
		String respuesta = "";
		for (Factura factura : facturas) {
			respuesta += factura + "\n";
			respuesta += "--------------------------------------------------------------\n";
		}
		texto.setText(respuesta);
	}
	
	@Override
	public void listaFacturasCliente(Collection<Factura> facturas) {
		controlador.buscarFacturasPorFecha(facturas);
	}
	
	@Override
	public void dameFacturas(ArrayList<Factura> lista) {
		String respuesta = "";
		for (Factura factura : lista) {
			respuesta += factura + "\n";
			respuesta += "--------------------------------------------------------------\n";
		}
		texto.setText(respuesta);
	}
}