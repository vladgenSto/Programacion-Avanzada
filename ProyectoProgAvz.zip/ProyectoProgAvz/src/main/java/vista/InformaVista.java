package vista;

import java.util.ArrayList;
import java.util.Collection;

import modelo.Cliente;
import modelo.Factura;
import modelo.Llamada;

public interface InformaVista {

	void nuevoCliente();
	
	void clienteEliminado();
		
	void tarifaCambiada();
	
	void infoCliente();

	void dameClientes(ArrayList<Cliente> clientes);
	
	void nuevaLlamada();
	
	void listaLlamadas(Collection<Llamada> lista);
	
	void actualizarListaLlamadas(Collection<Llamada> lista);
	
	void dameLlamadas(ArrayList<Llamada> llamadas);
	
	void facturaEmitida(String codFac);
	
	void dameFacturasCliente(Collection<Factura> facturas);
	
	void datosFac(Factura factura);
	
	void listadoFacturasCliente(Collection<Factura> facturas);
	
	void listaFacturasCliente(Collection<Factura> facturas);
	
	void dameFacturas(ArrayList<Factura> lista);
}
