package vista;

import java.util.ArrayList;
import java.util.Date;

import excepciones.ExcepcionNIF;
import modelo.Cliente;

public interface InterrogaVista {

	String getTipoCliente();
	
	String getNombre();
	
	String getApellido();

	String getNIF();
	
	String getPoblacion();

	String getProv();

	String getCodPostal();
	
	String getTipoTarifa();
	
	String getNumero();
	
	int getDuracion();
	
	String getCodFac();
	
	Date getFechaIn();
	
	Date getFechaFin();
	
	ArrayList<Cliente> listaDeClientes();
}
